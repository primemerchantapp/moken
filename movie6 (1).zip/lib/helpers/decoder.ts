export function decrypt(data: string, key: string): string {
  try {
    // Simple implementation - you may need to adjust based on the actual decryption logic
    let result = ""
    for (let i = 0; i < data.length; i++) {
      const charCode = data.charCodeAt(i) ^ key.charCodeAt(i % key.length)
      result += String.fromCharCode(charCode)
    }
    return result
  } catch (error) {
    console.error("Decryption error:", error)
    return ""
  }
}

