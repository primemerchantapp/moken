/**
 * Add event listener on multiple elements
 * @param {NodeList} $elements NodeList
 * @param {string} eventType Event Type eg. "click", "mouseover"
 * @param {function} callback  Callback function
 */
export const addEventOnElements = ($elements, eventType, callback) => {
  for (const $element of $elements) {
    $element.addEventListener(eventType, callback)
  }
}

