/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  swcMinify: true,
  images: {
    domains: ["image.tmdb.org", "hebbkx1anhila5yf.public.blob.vercel-storage.com"],
  },
  // Ensure output directory is properly set
  distDir: ".next",
}

module.exports = nextConfig

