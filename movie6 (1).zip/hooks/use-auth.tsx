"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"

export interface User {
  id: string
  walletAddress: string
  walletType: "ethereum" | "solana"
  mkoBalance: number
  isSubscribed: boolean
  username?: string
  avatar?: string
  joinedDate: Date
  referralCode?: string
  referrerId?: string
}

interface AuthState {
  user: User | null
  isAuthenticated: boolean
  loading: boolean
  login: (walletAddress: string, walletType: "ethereum" | "solana", referrerId?: string) => Promise<void>
  logout: () => void
  checkTokenBalance: () => Promise<number>
}

const AuthContext = createContext<AuthState | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)

  // Check if user is logged in from localStorage on initial load
  useEffect(() => {
    const storedUser = localStorage.getItem("moken-user")
    if (storedUser) {
      try {
        const userData = JSON.parse(storedUser)
        setUser({
          ...userData,
          joinedDate: new Date(userData.joinedDate),
        })
      } catch (e) {
        console.error("Failed to parse stored user data:", e)
        localStorage.removeItem("moken-user")
      }
    }
    setLoading(false)
  }, [])

  const login = async (walletAddress: string, walletType: "ethereum" | "solana", referrerId?: string) => {
    // In a real app, we would verify the wallet ownership by asking the user to sign a message
    // and verify the signature on the backend

    // Generate a unique referral code
    const referralCode = `${Math.random().toString(36).substring(2, 8)}${Date.now().toString(36).substring(4)}`

    // For demo purposes, we'll create a mock user
    const newUser: User = {
      id: `user_${Date.now()}`,
      walletAddress,
      walletType,
      mkoBalance: Math.floor(Math.random() * 1000) + 10,
      isSubscribed: true,
      joinedDate: new Date(),
      username:
        walletType === "ethereum" ? `eth_user_${walletAddress.slice(0, 6)}` : `sol_user_${walletAddress.slice(0, 6)}`,
      avatar:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot_20250313_094208_ChatGPT.jpg-4WW7mASz2HaCQJPUdHUjtloaP0HfwP.jpeg",
      referralCode,
      referrerId, // Store the referrer's ID if provided
    }

    setUser(newUser)

    // Store user in localStorage for persistence
    localStorage.setItem("moken-user", JSON.stringify(newUser))

    // In a real app, we would also make an API call to register the user and their referrer
    if (referrerId) {
      console.log(`User signed up with referral ID: ${referrerId}`)
      // Here you would credit the referrer
    }
  }

  const logout = () => {
    setUser(null)
    localStorage.removeItem("moken-user")
  }

  const checkTokenBalance = async (): Promise<number> => {
    // In a real app, we would fetch the token balance from the blockchain
    // For demo purposes, we'll return the mock balance
    return user?.mkoBalance || 0
  }

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: !!user,
        loading,
        login,
        logout,
        checkTokenBalance,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export function useAuthState() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuthState must be used within an AuthProvider")
  }
  return context
}

