"use client"

import { useState, useEffect } from "react"
import { Header } from "../components/header"
import { BottomNav } from "../components/bottom-nav"
import { MusicPlayer } from "./components/music-player"
import { VideoPlayer } from "./components/video-player"
import { AlbumSection } from "./components/album-section"
import { PlaylistSection } from "./components/playlist-section"
import { SplashScreen } from "../components/splash-screen"
import {
  fetchArtist,
  fetchArtistReleases,
  fetchPopularTracks,
  getAudioSampleUrl,
  type Album,
  type AudioPlayerTrack,
} from "./api"

// Default artist to feature (Coldplay)
const DEFAULT_ARTIST_ID = "cc197bad-dc9c-440d-a5b5-d52ba2e14234"

export default function MusicPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [searchResults, setSearchResults] = useState([])
  const [showSearchResults, setShowSearchResults] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  // Artist and music data state
  const [artist, setArtist] = useState<any>(null)
  const [albums, setAlbums] = useState<Album[]>([])
  const [popularTracks, setPopularTracks] = useState<any[]>([])

  // Current track and video state
  const [currentTrack, setCurrentTrack] = useState<AudioPlayerTrack | null>(null)
  const [currentVideo, setCurrentVideo] = useState({
    id: "1",
    title: "Yellow",
    artist: "Coldplay",
    thumbnail:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/video-thumbnail-Yd9Iy9Yd9Iy9Yd9Iy9Yd9Iy9Yd9Iy.jpg",
    videoUrl: "https://www.youtube.com/embed/yKNxeF4KMsY", // Coldplay - Yellow video
  })

  useEffect(() => {
    // Set the document title
    document.title = "MOKEN - Music Streaming"

    // Fetch data from MusicBrainz
    const fetchData = async () => {
      try {
        setIsLoading(true)

        // Fetch artist info
        const artistData = await fetchArtist(DEFAULT_ARTIST_ID)
        setArtist(artistData)

        // Fetch artist's albums
        const albumsData = await fetchArtistReleases(DEFAULT_ARTIST_ID, 12)
        setAlbums(albumsData["release-groups"] || [])

        // Fetch popular tracks - handle potential errors
        try {
          const tracksData = await fetchPopularTracks(DEFAULT_ARTIST_ID)
          setPopularTracks(tracksData.payload?.recordings || [])

          // Set initial current track if available
          if (tracksData.payload?.recordings?.length > 0) {
            const track = tracksData.payload.recordings[0]
            setCurrentTrack({
              id: track.recording_mbid || "1",
              title: track.recording_name,
              artist: artistData.name,
              album: track.release_name || "Unknown Album",
              cover: `https://api.napster.com/imageserver/v2/albums/${track.recording_mbid}/images/500x500.jpg`,
              audio: getAudioSampleUrl(track.recording_name),
            })
          }
        } catch (trackError) {
          console.error("Error fetching tracks, using empty array:", trackError)
          setPopularTracks([])
        }

        setIsLoading(false)
      } catch (err) {
        console.error("Error fetching music data:", err)
        setError("Failed to load music data. Please try again later.")
        setIsLoading(false)
      }
    }

    fetchData()
  }, [])

  const handleSearch = (query: string) => {
    setSearchQuery(query)
    // Mock search functionality
    if (query.trim()) {
      setSearchResults([])
      setShowSearchResults(true)
    } else {
      setShowSearchResults(false)
    }
  }

  const handleTrackSelect = (track: AudioPlayerTrack) => {
    setCurrentTrack(track)
  }

  const handleVideoSelect = (video: any) => {
    setCurrentVideo(video)
  }

  if (isLoading) {
    return <SplashScreen />
  }

  if (error) {
    return (
      <div className="min-h-screen bg-[#141414] text-white flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Error</h1>
          <p className="mb-4">{error}</p>
          <button className="bg-[#e50914] px-4 py-2 rounded" onClick={() => window.location.reload()}>
            Try Again
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-[#141414] text-white">
      {/* Header */}
      <Header onSearch={handleSearch} searchResults={searchResults} showSearchResults={showSearchResults} />

      <main className="pt-16 pb-20">
        {/* Featured Section with Player */}
        <section className="relative w-full bg-gradient-to-b from-[#1a1a1a] to-[#141414] px-4 py-8 md:px-8 lg:px-14">
          <div className="max-w-7xl mx-auto">
            <h1 className="text-3xl md:text-4xl font-bold mb-6">{artist ? artist.name : "Music"}</h1>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-10">
              {/* Music Player */}
              <div className="bg-[#181818] rounded-lg overflow-hidden shadow-lg">
                {currentTrack && <MusicPlayer track={currentTrack} />}
              </div>

              {/* Video Player */}
              <div className="bg-[#181818] rounded-lg overflow-hidden shadow-lg">
                <VideoPlayer video={currentVideo} />
              </div>
            </div>
          </div>
        </section>

        {/* Albums Section */}
        {albums.length > 0 && (
          <AlbumSection
            albums={albums}
            artistName={artist?.name || "Unknown Artist"}
            onTrackSelect={handleTrackSelect}
            onVideoSelect={handleVideoSelect}
          />
        )}

        {/* Popular Tracks Section */}
        {popularTracks.length > 0 && (
          <PlaylistSection
            popularTracks={popularTracks}
            artistName={artist?.name || "Unknown Artist"}
            onTrackSelect={handleTrackSelect}
          />
        )}
      </main>

      {/* Bottom Navigation */}
      <BottomNav />
    </div>
  )
}

