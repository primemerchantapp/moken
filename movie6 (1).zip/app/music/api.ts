// MusicBrainz API utilities

// API base URLs
const MB_API_URL = "https://musicbrainz.org/ws/2"
const LB_API_URL = "https://api.listenbrainz.org/1"
const COVER_ART_URL = "https://coverartarchive.org"

// Default headers for MusicBrainz API
const headers = {
  Accept: "application/json",
  "User-Agent": "MOKEN_Music_App/1.0 (https://moken-movie.vercel.app)",
}

// Function to fetch artist data
export async function fetchArtist(mbid: string) {
  const response = await fetch(`${MB_API_URL}/artist/${mbid}?inc=url-rels+releases+release-groups&fmt=json`, {
    headers,
  })
  return await response.json()
}

// Function to fetch artist's releases (albums)
export async function fetchArtistReleases(mbid: string, limit = 10) {
  const response = await fetch(`${MB_API_URL}/release-group?artist=${mbid}&limit=${limit}&fmt=json&type=album`, {
    headers,
  })
  return await response.json()
}

// Function to fetch release details
export async function fetchRelease(mbid: string) {
  const response = await fetch(`${MB_API_URL}/release/${mbid}?inc=recordings+artist-credits&fmt=json`, { headers })
  return await response.json()
}

// Function to fetch cover art for a release
export async function fetchCoverArt(mbid: string) {
  try {
    const response = await fetch(`${COVER_ART_URL}/release-group/${mbid}`, { headers })
    return await response.json()
  } catch (error) {
    console.error("Cover art not found for", mbid)
    return null
  }
}

// Function to fetch popular tracks from ListenBrainz
export async function fetchPopularTracks(mbid: string) {
  try {
    console.log(`Fetching popular tracks for artist: ${mbid}`)
    const response = await fetch(`${LB_API_URL}/stats/artist/${mbid}/recordings?count=10`, { headers })

    if (!response.ok) {
      console.warn(`ListenBrainz API returned status ${response.status} for artist ${mbid}`)
      return getMockPopularTracks()
    }

    const data = await response.json()

    // Check if the response has the expected structure
    if (!data.payload || !data.payload.recordings || data.payload.recordings.length === 0) {
      console.warn(`No recordings found in ListenBrainz response for artist ${mbid}`)
      return getMockPopularTracks()
    }

    return data
  } catch (error) {
    console.warn(`Error fetching popular tracks for ${mbid}: ${error}`)
    return getMockPopularTracks()
  }
}

// Add a separate function for mock data to improve code organization
function getMockPopularTracks() {
  return {
    payload: {
      recordings: [
        {
          recording_mbid: "c9fb31b3-9a6a-4850-89c0-32c7b3a7f9db",
          recording_name: "Yellow",
          release_name: "Parachutes",
          listen_count: 12345,
        },
        {
          recording_mbid: "d9fb31b3-9a6a-4850-89c0-32c7b3a7f9dc",
          recording_name: "The Scientist",
          release_name: "A Rush of Blood to the Head",
          listen_count: 10987,
        },
        {
          recording_mbid: "e9fb31b3-9a6a-4850-89c0-32c7b3a7f9dd",
          recording_name: "Viva la Vida",
          release_name: "Viva la Vida or Death and All His Friends",
          listen_count: 9876,
        },
        {
          recording_mbid: "f9fb31b3-9a6a-4850-89c0-32c7b3a7f9de",
          recording_name: "Fix You",
          release_name: "X&Y",
          listen_count: 8765,
        },
        {
          recording_mbid: "a9fb31b3-9a6a-4850-89c0-32c7b3a7f9df",
          recording_name: "Paradise",
          release_name: "Mylo Xyloto",
          listen_count: 7654,
        },
        {
          recording_mbid: "b9fb31b3-9a6a-4850-89c0-32c7b3a7f9ea",
          recording_name: "Clocks",
          release_name: "A Rush of Blood to the Head",
          listen_count: 6543,
        },
        {
          recording_mbid: "c9fb31b3-9a6a-4850-89c0-32c7b3a7f9eb",
          recording_name: "Adventure of a Lifetime",
          release_name: "A Head Full of Dreams",
          listen_count: 5432,
        },
        {
          recording_mbid: "d9fb31b3-9a6a-4850-89c0-32c7b3a7f9ec",
          recording_name: "Hymn for the Weekend",
          release_name: "A Head Full of Dreams",
          listen_count: 4321,
        },
        {
          recording_mbid: "e9fb31b3-9a6a-4850-89c0-32c7b3a7f9ed",
          recording_name: "Something Just Like This",
          release_name: "Memories...Do Not Open",
          listen_count: 3210,
        },
        {
          recording_mbid: "f9fb31b3-9a6a-4850-89c0-32c7b3a7f9ee",
          recording_name: "A Sky Full of Stars",
          release_name: "Ghost Stories",
          listen_count: 2109,
        },
      ],
    },
  }
}

// For audio URL (since we don't have actual streaming URLs, we'll use samples)
export function getAudioSampleUrl(trackName: string) {
  // Use sample audio files from SoundHelix
  const trackId = Math.floor(Math.abs(hashCode(trackName) % 15)) + 1
  return `https://www.soundhelix.com/examples/mp3/SoundHelix-Song-${trackId}.mp3`
}

// Simple hash function for creating deterministic IDs
function hashCode(str: string) {
  let hash = 0
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i)
    hash = (hash << 5) - hash + char
    hash = hash & hash // Convert to 32bit integer
  }
  return hash
}

// Types for MusicBrainz data
export interface Artist {
  id: string
  name: string
  type: string
  country: string
  disambiguation: string
  "life-span": {
    begin: string
    end: string | null
    ended: boolean
  }
}

export interface Album {
  id: string
  title: string
  "first-release-date": string
  "primary-type": string
  "secondary-types"?: string[]
  disambiguation?: string
  artist_credit?: {
    name: string
    artist: {
      id: string
      name: string
    }
  }[]
}

export interface Track {
  id: string
  title: string
  artist: string
  duration: number
  album: string
  cover?: string
  audio?: string
  listen_count?: number
}

export interface AudioPlayerTrack {
  id: string
  title: string
  artist: string
  album: string
  cover: string
  audio: string
}

