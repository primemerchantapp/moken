"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import { ChevronRight } from "lucide-react"
import { fetchCoverArt, fetchRelease, getAudioSampleUrl, type Album, type AudioPlayerTrack } from "../api"

interface AlbumSectionProps {
  albums: Album[]
  artistName: string
  onTrackSelect: (track: AudioPlayerTrack) => void
  onVideoSelect: (video: any) => void
}

export function AlbumSection({ albums, artistName, onTrackSelect, onVideoSelect }: AlbumSectionProps) {
  const [expandedAlbum, setExpandedAlbum] = useState<string | null>(null)
  const [albumDetails, setAlbumDetails] = useState<{ [key: string]: any }>({})
  const [albumCovers, setAlbumCovers] = useState<{ [key: string]: string }>({})

  useEffect(() => {
    // Pre-fetch album covers for all albums
    const fetchCovers = async () => {
      const covers: { [key: string]: string } = {}

      for (const album of albums) {
        try {
          const coverData = await fetchCoverArt(album.id)
          if (coverData && coverData.images && coverData.images.length > 0) {
            covers[album.id] = coverData.images[0].thumbnails.small || coverData.images[0].image
          } else {
            // Use a placeholder image if no cover art found
            covers[album.id] = `/placeholder.svg?height=200&width=200&text=${encodeURIComponent(album.title)}`
          }
        } catch (error) {
          covers[album.id] = `/placeholder.svg?height=200&width=200&text=${encodeURIComponent(album.title)}`
        }
      }

      setAlbumCovers(covers)
    }

    fetchCovers()
  }, [albums])

  const toggleAlbum = async (albumId: string) => {
    if (expandedAlbum === albumId) {
      setExpandedAlbum(null)
    } else {
      setExpandedAlbum(albumId)

      // Fetch album details if not already loaded
      if (!albumDetails[albumId]) {
        try {
          // For demonstration, we'll use the first release of this release-group
          const releaseData = await fetchRelease(albumId)
          setAlbumDetails((prev) => ({
            ...prev,
            [albumId]: releaseData,
          }))
        } catch (error) {
          console.error("Error fetching album details:", error)
        }
      }
    }
  }

  const handleTrackSelect = (track: any, album: Album) => {
    onTrackSelect({
      id: track.id,
      title: track.title,
      artist: artistName,
      album: album.title,
      cover: albumCovers[album.id] || `/placeholder.svg?height=300&width=300&text=${encodeURIComponent(album.title)}`,
      audio: getAudioSampleUrl(track.title),
    })
  }

  // MusicBrainz doesn't provide music videos, so we'll use some predefined ones
  const sampleVideos = [
    {
      id: "v1",
      title: "Yellow",
      artist: "Coldplay",
      thumbnail:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/video-thumbnail-Yd9Iy9Yd9Iy9Yd9Iy9Yd9Iy9Yd9Iy.jpg",
      videoUrl: "https://www.youtube.com/embed/yKNxeF4KMsY",
    },
    {
      id: "v2",
      title: "The Scientist",
      artist: "Coldplay",
      thumbnail:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/video-thumbnail2-Yd9Iy9Yd9Iy9Yd9Iy9Yd9Iy9Yd9Iy.jpg",
      videoUrl: "https://www.youtube.com/embed/RB-RcX5DS5A",
    },
  ]

  return (
    <section className="px-4 py-8 md:px-8 lg:px-14">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl md:text-3xl font-bold">Albums</h2>
          <button className="text-sm text-[#b3b3b3] hover:text-white flex items-center">
            See All <ChevronRight size={16} />
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {albums.map((album) => (
            <div key={album.id} className="flex flex-col">
              <div
                className="relative aspect-square rounded-md overflow-hidden cursor-pointer group"
                onClick={() => toggleAlbum(album.id)}
              >
                <Image
                  src={
                    albumCovers[album.id] ||
                    `/placeholder.svg?height=300&width=300&text=${encodeURIComponent(album.title)}`
                  }
                  alt={album.title}
                  fill
                  className="object-cover transition-transform duration-300 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                  <div className="w-12 h-12 rounded-full bg-[#e50914]/80 flex items-center justify-center">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M8 5V19L19 12L8 5Z" fill="white" />
                    </svg>
                  </div>
                </div>
              </div>
              <div className="mt-2">
                <h3 className="font-medium truncate">{album.title}</h3>
                <p className="text-sm text-[#b3b3b3] truncate">
                  {album["first-release-date"]?.split("-")[0] || "Unknown year"}
                </p>
              </div>

              {/* Expanded Album View */}
              {expandedAlbum === album.id && (
                <div className="mt-4 bg-[#181818] rounded-md p-4 shadow-lg">
                  <h4 className="font-medium mb-2">Tracks</h4>
                  <ul className="space-y-2 mb-4">
                    {albumDetails[album.id]?.media?.[0]?.tracks?.map((track: any) => (
                      <li
                        key={track.id}
                        className="flex items-center gap-3 p-2 hover:bg-white/10 rounded cursor-pointer"
                        onClick={() => handleTrackSelect(track, album)}
                      >
                        <div className="w-8 h-8 relative flex-shrink-0">
                          <Image
                            src={
                              albumCovers[album.id] ||
                              `/placeholder.svg?height=32&width=32&text=${encodeURIComponent(album.title)}`
                            }
                            alt={track.title}
                            fill
                            className="object-cover rounded"
                          />
                        </div>
                        <div className="overflow-hidden">
                          <p className="truncate">{track.title}</p>
                          <p className="text-xs text-[#b3b3b3] truncate">
                            {track.length
                              ? Math.floor(track.length / 1000 / 60) +
                                ":" +
                                Math.floor((track.length / 1000) % 60)
                                  .toString()
                                  .padStart(2, "0")
                              : "--:--"}
                          </p>
                        </div>
                      </li>
                    )) || <li className="text-center py-2 text-[#b3b3b3]">No tracks available</li>}
                  </ul>

                  {/* Videos section - using sample videos since MusicBrainz doesn't have videos */}
                  <h4 className="font-medium mb-2">Videos</h4>
                  <ul className="space-y-2">
                    {sampleVideos.slice(0, 2).map((video) => (
                      <li
                        key={video.id}
                        className="flex items-center gap-3 p-2 hover:bg-white/10 rounded cursor-pointer"
                        onClick={() => onVideoSelect(video)}
                      >
                        <div className="w-12 h-8 relative flex-shrink-0">
                          <Image
                            src={video.thumbnail || "/placeholder.svg?height=32&width=48"}
                            alt={video.title}
                            fill
                            className="object-cover rounded"
                          />
                          <div className="absolute inset-0 flex items-center justify-center">
                            <div className="w-4 h-4 rounded-full bg-[#e50914]/80 flex items-center justify-center">
                              <svg
                                width="8"
                                height="8"
                                viewBox="0 0 24 24"
                                fill="none"
                                xmlns="http://www.w3.org/2000/svg"
                              >
                                <path d="M8 5V19L19 12L8 5Z" fill="white" />
                              </svg>
                            </div>
                          </div>
                        </div>
                        <div className="overflow-hidden">
                          <p className="truncate">{video.title}</p>
                          <p className="text-xs text-[#b3b3b3] truncate">{video.artist}</p>
                        </div>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

