"use client"

import { useState } from "react"
import Image from "next/image"

interface Video {
  id: string
  title: string
  artist: string
  thumbnail: string
  videoUrl: string
}

interface VideoPlayerProps {
  video: Video
}

export function VideoPlayer({ video }: VideoPlayerProps) {
  const [isPlaying, setIsPlaying] = useState(false)

  return (
    <div className="h-full">
      {isPlaying ? (
        <div className="w-full h-full aspect-video">
          <iframe
            src={video.videoUrl}
            title={video.title}
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
            className="w-full h-full"
          ></iframe>
        </div>
      ) : (
        <div className="relative w-full h-full aspect-video cursor-pointer" onClick={() => setIsPlaying(true)}>
          <Image
            src={video.thumbnail || "/placeholder.svg?height=270&width=480"}
            alt={video.title}
            fill
            className="object-cover"
          />
          <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
            <div className="w-16 h-16 rounded-full bg-[#e50914]/80 flex items-center justify-center">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M8 5V19L19 12L8 5Z" fill="white" />
              </svg>
            </div>
          </div>
          <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/80 to-transparent">
            <h3 className="text-xl font-bold">{video.title}</h3>
            <p className="text-[#b3b3b3]">{video.artist}</p>
          </div>
        </div>
      )}
    </div>
  )
}

