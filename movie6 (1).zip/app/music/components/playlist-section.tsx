"use client"

import Image from "next/image"
import { ChevronRight } from "lucide-react"
import { getAudioSampleUrl, type AudioPlayerTrack } from "../api"

interface PlaylistSectionProps {
  popularTracks: any[]
  artistName: string
  onTrackSelect: (track: AudioPlayerTrack) => void
}

export function PlaylistSection({ popularTracks, artistName, onTrackSelect }: PlaylistSectionProps) {
  // Process popular tracks into playlists
  const createPlaylists = () => {
    if (!popularTracks || popularTracks.length === 0) {
      return []
    }

    // Create "Most Popular" playlist
    const mostPopular = {
      id: "most-popular",
      title: "Most Popular Tracks",
      description: `The most played tracks from ${artistName}`,
      cover:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/playlist1-cover-Yd9Iy9Yd9Iy9Yd9Iy9Yd9Iy9Yd9Iy.jpg",
      tracks: popularTracks.slice(0, 5).map((track) => ({
        id: track.recording_mbid || `p1-${track.recording_name}`,
        title: track.recording_name,
        artist: artistName,
        album: track.release_name || "Unknown Album",
        cover: `https://api.napster.com/imageserver/v2/albums/${track.recording_mbid}/images/500x500.jpg`,
        audio: getAudioSampleUrl(track.recording_name),
        listen_count: track.listen_count,
      })),
    }

    // Create "Similar Vibes" playlist with the remaining tracks
    const similarVibes = {
      id: "similar-vibes",
      title: "Similar Vibes",
      description: `More tracks from ${artistName} that you might enjoy`,
      cover:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/playlist2-cover-Yd9Iy9Yd9Iy9Yd9Iy9Yd9Iy9Yd9Iy.jpg",
      tracks: popularTracks.slice(5).map((track) => ({
        id: track.recording_mbid || `p2-${track.recording_name}`,
        title: track.recording_name,
        artist: artistName,
        album: track.release_name || "Unknown Album",
        cover: `https://api.napster.com/imageserver/v2/albums/${track.recording_mbid}/images/500x500.jpg`,
        audio: getAudioSampleUrl(track.recording_name),
        listen_count: track.listen_count,
      })),
    }

    return [mostPopular, similarVibes]
  }

  const playlists = createPlaylists()

  return (
    <section className="px-4 py-8 md:px-8 lg:px-14">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl md:text-3xl font-bold">Popular Tracks</h2>
          <button className="text-sm text-[#b3b3b3] hover:text-white flex items-center">
            See All <ChevronRight size={16} />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {playlists.map((playlist) => (
            <div
              key={playlist.id}
              className="bg-[#181818] rounded-md overflow-hidden hover:bg-[#282828] transition-colors p-4"
            >
              <div className="relative aspect-square rounded-md overflow-hidden mb-4 shadow-lg">
                <Image
                  src={playlist.cover || "/placeholder.svg?height=300&width=300"}
                  alt={playlist.title}
                  fill
                  className="object-cover"
                />
                <div className="absolute bottom-2 right-2 w-12 h-12 rounded-full bg-[#e50914] flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity shadow-lg transform translate-y-2 hover:translate-y-0">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M8 5V19L19 12L8 5Z" fill="white" />
                  </svg>
                </div>
              </div>
              <h3 className="font-bold mb-1">{playlist.title}</h3>
              <p className="text-sm text-[#b3b3b3] mb-4 line-clamp-2">{playlist.description}</p>

              <h4 className="text-sm font-medium mb-2">Top tracks:</h4>
              <ul className="space-y-2">
                {playlist.tracks.slice(0, 3).map((track) => (
                  <li
                    key={track.id}
                    className="flex items-center gap-3 p-2 hover:bg-white/10 rounded cursor-pointer"
                    onClick={() => onTrackSelect(track)}
                  >
                    <div className="w-8 h-8 relative flex-shrink-0">
                      <Image
                        src={track.cover || "/placeholder.svg?height=32&width=32"}
                        alt={track.title}
                        fill
                        className="object-cover rounded"
                      />
                    </div>
                    <div className="overflow-hidden flex-1">
                      <p className="truncate">{track.title}</p>
                      <p className="text-xs text-[#b3b3b3] truncate">{track.artist}</p>
                    </div>
                    <div className="text-xs text-[#b3b3b3]">
                      {track.listen_count && `${track.listen_count.toLocaleString()} plays`}
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

