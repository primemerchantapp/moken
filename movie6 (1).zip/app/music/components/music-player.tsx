"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import Image from "next/image"
import { Play, Pause, SkipBack, SkipForward, Volume2, VolumeX, Repeat, Shuffle } from "lucide-react"

// Update the interface to match our API tracks
interface Track {
  id: string
  title: string
  artist: string
  album: string
  cover: string
  audio: string
}

interface MusicPlayerProps {
  track: Track
}

export function MusicPlayer({ track }: MusicPlayerProps) {
  const [isPlaying, setIsPlaying] = useState(false)
  const [duration, setDuration] = useState(0)
  const [currentTime, setCurrentTime] = useState(0)
  const [volume, setVolume] = useState(0.7)
  const [isMuted, setIsMuted] = useState(false)
  const audioRef = useRef<HTMLAudioElement>(null)
  const progressBarRef = useRef<HTMLDivElement>(null)

  // Make sure we handle loading errors gracefully
  useEffect(() => {
    // Reset player when track changes
    setIsPlaying(false)
    setCurrentTime(0)

    // Small delay to ensure audio element is updated
    const timer = setTimeout(() => {
      if (audioRef.current) {
        audioRef.current.currentTime = 0
        audioRef.current.volume = volume
        // Try to autoplay if possible
        audioRef.current.play().catch((e) => {
          console.log("Autoplay prevented:", e)
        })
      }
    }, 100)

    return () => clearTimeout(timer)
  }, [track, volume])

  const togglePlay = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause()
      } else {
        audioRef.current.play()
      }
      setIsPlaying(!isPlaying)
    }
  }

  const handleTimeUpdate = () => {
    if (audioRef.current) {
      setCurrentTime(audioRef.current.currentTime)
      setDuration(audioRef.current.duration)
    }
  }

  const handleProgressChange = (e: React.MouseEvent<HTMLDivElement>) => {
    if (progressBarRef.current && audioRef.current) {
      const rect = progressBarRef.current.getBoundingClientRect()
      const pos = (e.clientX - rect.left) / rect.width
      audioRef.current.currentTime = pos * duration
    }
  }

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newVolume = Number.parseFloat(e.target.value)
    setVolume(newVolume)
    if (audioRef.current) {
      audioRef.current.volume = newVolume
    }
    if (newVolume === 0) {
      setIsMuted(true)
    } else {
      setIsMuted(false)
    }
  }

  const toggleMute = () => {
    if (audioRef.current) {
      if (isMuted) {
        audioRef.current.volume = volume
      } else {
        audioRef.current.volume = 0
      }
      setIsMuted(!isMuted)
    }
  }

  const formatTime = (time: number) => {
    if (isNaN(time)) return "0:00"
    const minutes = Math.floor(time / 60)
    const seconds = Math.floor(time % 60)
    return `${minutes}:${seconds.toString().padStart(2, "0")}`
  }

  // Add an error handler for the audio element
  const handleError = () => {
    console.error("Error loading audio")
    setIsPlaying(false)
  }

  return (
    <div className="p-4">
      <div className="flex flex-col md:flex-row items-center gap-6">
        {/* Album Cover */}
        <div className="relative w-full md:w-48 h-48 rounded-md overflow-hidden shadow-lg">
          <Image
            src={track.cover || "/placeholder.svg?height=192&width=192"}
            alt={track.title}
            fill
            className="object-cover"
          />
        </div>

        {/* Player Controls */}
        <div className="flex-1 w-full">
          <div className="mb-4">
            <h3 className="text-xl font-bold truncate">{track.title}</h3>
            <p className="text-[#b3b3b3]">
              {track.artist} • {track.album}
            </p>
          </div>

          {/* Progress Bar */}
          <div
            ref={progressBarRef}
            className="h-1 bg-[#535353] rounded-full mb-2 cursor-pointer"
            onClick={handleProgressChange}
          >
            <div
              className="h-full bg-[#e50914] rounded-full"
              style={{ width: `${(currentTime / duration) * 100 || 0}%` }}
            ></div>
          </div>

          {/* Time Display */}
          <div className="flex justify-between text-xs text-[#b3b3b3] mb-4">
            <span>{formatTime(currentTime)}</span>
            <span>{formatTime(duration)}</span>
          </div>

          {/* Controls */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <button className="text-[#b3b3b3] hover:text-white transition-colors">
                <Shuffle size={20} />
              </button>
              <button className="text-[#b3b3b3] hover:text-white transition-colors">
                <SkipBack size={24} />
              </button>
              <button
                className="bg-white text-black rounded-full p-2 hover:scale-105 transition-transform"
                onClick={togglePlay}
              >
                {isPlaying ? <Pause size={24} /> : <Play size={24} />}
              </button>
              <button className="text-[#b3b3b3] hover:text-white transition-colors">
                <SkipForward size={24} />
              </button>
              <button className="text-[#b3b3b3] hover:text-white transition-colors">
                <Repeat size={20} />
              </button>
            </div>

            {/* Volume Control */}
            <div className="hidden md:flex items-center gap-2">
              <button onClick={toggleMute}>{isMuted ? <VolumeX size={20} /> : <Volume2 size={20} />}</button>
              <input
                type="range"
                min="0"
                max="1"
                step="0.01"
                value={isMuted ? 0 : volume}
                onChange={handleVolumeChange}
                className="w-20 accent-[#e50914]"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Audio Element */}
      <audio
        ref={audioRef}
        src={track.audio}
        onTimeUpdate={handleTimeUpdate}
        onLoadedMetadata={handleTimeUpdate}
        onEnded={() => setIsPlaying(false)}
        onError={handleError}
      />
    </div>
  )
}

