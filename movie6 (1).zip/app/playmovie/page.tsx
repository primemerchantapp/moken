"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { ArrowLeft } from "lucide-react"
import { useAuthState } from "@/hooks/use-auth"
import { AuthModal } from "../profile/components/auth-modal"

export default function PlayMoviePage() {
  const router = useRouter()
  const { isAuthenticated, loading } = useAuthState()
  const [streamURL, setStreamURL] = useState("")
  const [movieTitle, setMovieTitle] = useState("")
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [showAuthModal, setShowAuthModal] = useState(false)

  useEffect(() => {
    // Check authentication first
    if (!loading && !isAuthenticated) {
      setShowAuthModal(true)
      return
    }

    async function setupStreamSources() {
      try {
        setIsLoading(true)

        // Get movie details from localStorage
        const movieId = localStorage.getItem("movieId")
        const title = localStorage.getItem("movieTitle") || "Movie"
        const imdbId = localStorage.getItem("imdbId") || ""

        if (!movieId) {
          router.back()
          return
        }

        setMovieTitle(title)
        document.title = `Watch ${title} - MOKEN`

        // Create direct vidsrc URLs using the official API endpoints
        // Using vidsrc.xyz as the primary domain as specified
        const vidsrcXyz = imdbId
          ? `https://vidsrc.xyz/embed/movie?imdb=${imdbId}`
          : `https://vidsrc.xyz/embed/movie?tmdb=${movieId}`

        // Create backup URLs with alternative domains
        const vidsrcNet = imdbId
          ? `https://vidsrc.net/embed/movie?imdb=${imdbId}`
          : `https://vidsrc.net/embed/movie?tmdb=${movieId}`

        const vidsrcIn = imdbId
          ? `https://vidsrc.in/embed/movie?imdb=${imdbId}`
          : `https://vidsrc.in/embed/movie?tmdb=${movieId}`

        const vidsrcPm = imdbId
          ? `https://vidsrc.pm/embed/movie?imdb=${imdbId}`
          : `https://vidsrc.pm/embed/movie?tmdb=${movieId}`

        // Set the primary streaming URL
        setStreamURL(vidsrcXyz)

        // Store backup sources
        const backupSources = {
          vidsrcXyz: vidsrcXyz,
          vidsrcNet: vidsrcNet,
          vidsrcIn: vidsrcIn,
          vidsrcPm: vidsrcPm,
        }

        // Store for potential fallback
        localStorage.setItem("streamBackups", JSON.stringify(backupSources))
      } catch (err) {
        console.error("Error setting up stream sources:", err)
        // Fall back to the stored URL
        const fallbackURL = localStorage.getItem("streamURL")
        if (fallbackURL) {
          setStreamURL(fallbackURL)
        } else {
          setError("Failed to load streaming sources")
        }
      } finally {
        setIsLoading(false)
      }
    }

    if (isAuthenticated) {
      setupStreamSources()
    }
  }, [router, isAuthenticated, loading])

  const goBack = () => {
    router.back()
  }

  if (showAuthModal) {
    return (
      <div className="min-h-screen bg-black">
        <AuthModal
          onClose={() => {
            // If they cancel authentication, redirect back
            router.back()
          }}
        />
      </div>
    )
  }

  if (loading || isLoading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="w-16 h-16 border-4 border-[#e50914] border-r-transparent rounded-full animate-spin"></div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="bg-[#232323] p-6 rounded-lg max-w-md text-center">
          <h2 className="text-xl font-bold mb-4">Error</h2>
          <p className="mb-4">{error}</p>
          <button onClick={goBack} className="bg-[#e50914] text-white px-4 py-2 rounded">
            Go Back
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-black relative">
      {/* Back button */}
      <div className="absolute top-4 left-4 z-50">
        <button
          onClick={goBack}
          className="bg-black/50 text-white rounded-full p-2 hover:bg-black/80 transition-colors"
        >
          <ArrowLeft size={24} />
        </button>
      </div>

      {/* Title */}
      <div className="absolute top-4 left-16 z-50">
        <h1 className="text-white font-bold text-xl">{movieTitle}</h1>
      </div>

      {/* Full-screen iframe for video */}
      <div className="w-screen h-screen">
        <iframe src={streamURL} className="w-full h-full" allowFullScreen allow="autoplay; fullscreen"></iframe>
      </div>
    </div>
  )
}

