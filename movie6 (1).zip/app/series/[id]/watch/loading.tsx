export default function Loading() {
  return (
    <div className="min-h-screen bg-black flex items-center justify-center">
      <div className="w-16 h-16 border-4 border-[#e50914] border-r-transparent rounded-full animate-spin"></div>
    </div>
  )
}

