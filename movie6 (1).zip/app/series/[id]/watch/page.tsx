"use client"

import { useEffect, useState, useRef } from "react"
import { useRouter } from "next/navigation"
import { ArrowLeft } from "lucide-react"
import { Header } from "../../../components/header"

// API configuration
const API_KEY = "7a5cf3c679b58ed507187030e928245a"

interface Episode {
  id: number
  name: string
  episode_number: number
  season_number: number
  still_path: string | null
  overview: string
  air_date: string
}

interface Season {
  id: number
  name: string
  season_number: number
  episode_count: number
}

interface Series {
  id: number
  name: string
  external_ids?: {
    imdb_id: string
    tvdb_id: number
    tvrage_id: number
  }
}

export default function WatchPage({ params }: { params: { id: string } }) {
  const router = useRouter()
  const [series, setSeries] = useState<Series | null>(null)
  const [seasons, setSeasons] = useState<Season[]>([])
  const [episodes, setEpisodes] = useState<Episode[]>([])
  const [currentSeason, setCurrentSeason] = useState(1)
  const [currentEpisode, setCurrentEpisode] = useState<Episode | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [streamURL, setStreamURL] = useState("")
  const [streamSources, setStreamSources] = useState<Record<string, string>>({})
  const videoContainer = useRef<HTMLDivElement>(null)

  // Add a function to handle orientation locking properly

  const requestLandscapeMode = () => {
    // First check if we're in fullscreen mode
    if (!document.fullscreenElement) {
      // If not in fullscreen, enter fullscreen first
      if (videoContainer.current) {
        if (videoContainer.current.requestFullscreen) {
          videoContainer.current.requestFullscreen()
        } else if ((videoContainer.current as any).webkitRequestFullscreen) {
          ;(videoContainer.current as any).webkitRequestFullscreen()
        } else if ((videoContainer.current as any).msRequestFullscreen) {
          ;(videoContainer.current as any).msRequestFullscreen()
        }
      }
      // The orientation lock will be handled in the fullscreenchange event handler
    } else {
      // If already in fullscreen, try to lock orientation
      tryLockOrientation()
    }
  }

  const tryLockOrientation = () => {
    if (typeof window !== "undefined" && "screen" in window && "orientation" in screen) {
      try {
        // Try to lock to landscape orientation (only works in fullscreen)
        ;(screen.orientation as any).lock("landscape").catch((err: any) => {
          console.error("Failed to lock orientation:", err)
        })
      } catch (err) {
        console.error("Orientation API not supported:", err)
        // Fallback for iOS
        if ((window as any).orientation !== undefined) {
          alert("Please rotate your device to landscape mode for the best viewing experience.")
        }
      }
    }
  }

  // Add a fullscreen change event listener
  useEffect(() => {
    const handleFullscreenChange = () => {
      if (document.fullscreenElement) {
        tryLockOrientation()
      }
    }

    document.addEventListener("fullscreenchange", handleFullscreenChange)
    document.addEventListener("webkitfullscreenchange", handleFullscreenChange)
    document.addEventListener("mozfullscreenchange", handleFullscreenChange)
    document.addEventListener("MSFullscreenChange", handleFullscreenChange)

    return () => {
      document.removeEventListener("fullscreenchange", handleFullscreenChange)
      document.removeEventListener("webkitfullscreenchange", handleFullscreenChange)
      document.removeEventListener("mozfullscreenchange", handleFullscreenChange)
      document.removeEventListener("MSFullscreenChange", handleFullscreenChange)
    }
  }, [])

  useEffect(() => {
    // Fetch series details
    fetch(`https://api.themoviedb.org/3/tv/${params.id}?api_key=${API_KEY}&append_to_response=external_ids`)
      .then((res) => res.json())
      .then((data) => {
        setSeries(data)
        setSeasons(data.seasons || [])
        document.title = `Watch ${data.name} - MOKEN`

        // Get season and episode from URL or localStorage
        const storedSeason = localStorage.getItem("seasonNumber") || "1"
        const storedEpisode = localStorage.getItem("episodeNumber") || "1"
        const seasonNumber = Number.parseInt(storedSeason, 10)

        setCurrentSeason(seasonNumber)

        // Fetch first season episodes by default
        return fetch(`https://api.themoviedb.org/3/tv/${params.id}/season/${seasonNumber}?api_key=${API_KEY}`)
      })
      .then((res) => res.json())
      .then((data) => {
        if (data.episodes && data.episodes.length > 0) {
          setEpisodes(data.episodes)

          // Get episode from localStorage or default to first
          const storedEpisode = localStorage.getItem("episodeNumber") || "1"
          const episodeNumber = Number.parseInt(storedEpisode, 10)

          // Find the episode
          const episode = data.episodes.find((ep: Episode) => ep.episode_number === episodeNumber) || data.episodes[0]
          setCurrentEpisode(episode)

          // Set up streaming sources
          setupStreamSources(params.id, series?.external_ids?.imdb_id, episode.season_number, episode.episode_number)
        }
        setIsLoading(false)
      })
      .catch((error) => {
        console.error("Error fetching series data:", error)
        setIsLoading(false)
      })
  }, [params.id])

  const setupStreamSources = (
    tmdbId: string,
    imdbId: string | undefined,
    seasonNumber: number,
    episodeNumber: number,
  ) => {
    // Create streaming sources with priority order using the official API endpoints
    const sources = {
      // Use vidsrc.xyz as primary domain
      vidsrcXyz: imdbId
        ? `https://vidsrc.xyz/embed/tv?imdb=${imdbId}&season=${seasonNumber}&episode=${episodeNumber}`
        : `https://vidsrc.xyz/embed/tv?tmdb=${tmdbId}&season=${seasonNumber}&episode=${episodeNumber}`,

      // Alternative domains as backups
      vidsrcNet: imdbId
        ? `https://vidsrc.net/embed/tv?imdb=${imdbId}&season=${seasonNumber}&episode=${episodeNumber}`
        : `https://vidsrc.net/embed/tv?tmdb=${tmdbId}&season=${seasonNumber}&episode=${episodeNumber}`,

      vidsrcIn: imdbId
        ? `https://vidsrc.in/embed/tv?imdb=${imdbId}&season=${seasonNumber}&episode=${episodeNumber}`
        : `https://vidsrc.in/embed/tv?tmdb=${tmdbId}&season=${seasonNumber}&episode=${episodeNumber}`,

      vidsrcPm: imdbId
        ? `https://vidsrc.pm/embed/tv?imdb=${imdbId}&season=${seasonNumber}&episode=${episodeNumber}`
        : `https://vidsrc.pm/embed/tv?tmdb=${tmdbId}&season=${seasonNumber}&episode=${episodeNumber}`,
    }

    setStreamSources(sources)
    setStreamURL(sources.vidsrcXyz) // Use vidsrc.xyz as primary

    // Store for the player page
    localStorage.setItem("streamURL", sources.vidsrcXyz)
    localStorage.setItem("streamBackups", JSON.stringify(sources))
    localStorage.setItem("seriesTitle", series?.name || "")
    localStorage.setItem("seasonNumber", seasonNumber.toString())
    localStorage.setItem("episodeNumber", episodeNumber.toString())
  }

  const handleSeasonChange = (seasonNumber: number) => {
    setCurrentSeason(seasonNumber)
    setIsLoading(true)

    fetch(`https://api.themoviedb.org/3/tv/${params.id}/season/${seasonNumber}?api_key=${API_KEY}`)
      .then((res) => res.json())
      .then((data) => {
        if (data.episodes && data.episodes.length > 0) {
          setEpisodes(data.episodes)
          setCurrentEpisode(data.episodes[0])

          // Update streaming sources for the first episode of the new season
          setupStreamSources(params.id, series?.external_ids?.imdb_id, seasonNumber, data.episodes[0].episode_number)
        }
        setIsLoading(false)
      })
      .catch((error) => {
        console.error("Error fetching season data:", error)
        setIsLoading(false)
      })
  }

  const handleEpisodeSelect = (episode: Episode) => {
    setCurrentEpisode(episode)

    // Update streaming sources for the new episode
    setupStreamSources(params.id, series?.external_ids?.imdb_id, episode.season_number, episode.episode_number)
  }

  const goBack = () => {
    router.back()
  }

  const openExternalPlayer = () => {
    // Navigate to the external player page
    window.location.href = "/playmovie.html"
  }

  const nextEpisode = () => {
    if (!currentEpisode) return

    const currentIndex = episodes.findIndex((ep) => ep.id === currentEpisode.id)
    if (currentIndex < episodes.length - 1) {
      handleEpisodeSelect(episodes[currentIndex + 1])
    } else if (currentSeason < seasons.length) {
      // Move to the next season
      handleSeasonChange(currentSeason + 1)
    }
  }

  const previousEpisode = () => {
    if (!currentEpisode) return

    const currentIndex = episodes.findIndex((ep) => ep.id === currentEpisode.id)
    if (currentIndex > 0) {
      handleEpisodeSelect(episodes[currentIndex - 1])
    } else if (currentSeason > 1) {
      // Move to the previous season (and its last episode)
      // This would require fetching the previous season's episodes first
      const prevSeason = currentSeason - 1
      fetch(`https://api.themoviedb.org/3/tv/${params.id}/season/${prevSeason}?api_key=${API_KEY}`)
        .then((res) => res.json())
        .then((data) => {
          if (data.episodes && data.episodes.length > 0) {
            setEpisodes(data.episodes)
            setCurrentSeason(prevSeason)
            setCurrentEpisode(data.episodes[data.episodes.length - 1])

            // Update streaming sources for the last episode of the previous season
            setupStreamSources(
              params.id,
              series?.external_ids?.imdb_id,
              prevSeason,
              data.episodes[data.episodes.length - 1].episode_number,
            )
          }
        })
    }
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="w-16 h-16 border-4 border-[#e50914] border-r-transparent rounded-full animate-spin"></div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-black text-white">
      <Header onSearch={() => {}} searchResults={[]} showSearchResults={false} />

      <main className="pt-16">
        <div className="flex flex-col lg:flex-row h-[calc(100vh-64px)]">
          {/* Video Player */}
          <div className="relative w-full lg:w-3/4 h-[40vh] lg:h-full bg-black" ref={videoContainer}>
            <div className="absolute top-4 left-4 z-10">
              <button
                onClick={goBack}
                className="flex items-center gap-2 text-white/80 hover:text-white bg-black/50 p-2 rounded-full"
              >
                <ArrowLeft size={20} />
              </button>
            </div>

            {streamURL && (
              <iframe src={streamURL} className="w-full h-full" allowFullScreen allow="autoplay; fullscreen"></iframe>
            )}

            <div className="absolute bottom-4 right-4 z-10">
              <button
                onClick={openExternalPlayer}
                className="flex items-center gap-2 text-white/80 hover:text-white bg-black/50 p-2 rounded"
              >
                Open in Full Player
              </button>
              <button
                onClick={requestLandscapeMode}
                className="flex items-center gap-2 text-white/80 hover:text-white bg-black/50 p-2 rounded"
              >
                Fullscreen
              </button>
            </div>
          </div>

          {/* Episodes List */}
          <div className="w-full lg:w-1/4 bg-[#141414] overflow-y-auto">
            <div className="p-4">
              <h2 className="text-xl font-bold mb-4">{series?.name}</h2>

              {/* Season Selector */}
              <div className="mb-4">
                <label className="block text-sm text-white/70 mb-1">Season</label>
                <select
                  value={currentSeason}
                  onChange={(e) => handleSeasonChange(Number.parseInt(e.target.value))}
                  className="w-full bg-[#232323] text-white p-2 rounded-md"
                >
                  {seasons.map((season) => (
                    <option key={season.id} value={season.season_number}>
                      {season.name} ({season.episode_count} episodes)
                    </option>
                  ))}
                </select>
              </div>

              {/* Episodes List */}
              <h3 className="text-lg font-bold mb-2">Episodes</h3>
              <div className="space-y-3">
                {episodes.map((episode) => (
                  <div
                    key={episode.id}
                    onClick={() => handleEpisodeSelect(episode)}
                    className={`flex gap-3 p-2 rounded-md cursor-pointer ${
                      currentEpisode?.id === episode.id
                        ? "bg-[#e50914]/20 border-l-4 border-[#e50914]"
                        : "hover:bg-[#232323]"
                    }`}
                  >
                    <div className="w-24 h-16 relative flex-shrink-0">
                      {episode.still_path ? (
                        <img
                          src={`https://image.tmdb.org/t/p/w300${episode.still_path}`}
                          alt={episode.name}
                          className="w-full h-full object-cover rounded-md"
                        />
                      ) : (
                        <div className="w-full h-full bg-[#232323] rounded-md flex items-center justify-center">
                          <span className="text-2xl">📺</span>
                        </div>
                      )}
                    </div>
                    <div className="flex-1">
                      <div className="flex justify-between">
                        <span className="text-sm text-white/70">Episode {episode.episode_number}</span>
                        <span className="text-sm text-white/70">{episode.air_date}</span>
                      </div>
                      <h4 className="font-medium">{episode.name}</h4>
                      <p className="text-xs text-white/70 line-clamp-2">{episode.overview}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}

