export default function Loading() {
  return (
    <div className="min-h-screen bg-[#141414] text-white flex items-center justify-center">
      <div className="w-16 h-16 border-4 border-[#e50914] border-r-transparent rounded-full animate-spin"></div>
    </div>
  )
}

