"use client"

import { useEffect, useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { Header } from "../../components/header"
import { BottomNav } from "../../components/bottom-nav"
import { SplashScreen } from "../../components/splash-screen"

// API configuration
const API_KEY = "7a5cf3c679b58ed507187030e928245a"
const IMAGE_BASE_URL = "https://image.tmdb.org/t/p/"

interface Series {
  id: number
  name: string
  poster_path: string
  backdrop_path: string
  vote_average: number
  first_air_date: string
  genres: { id: number; name: string }[]
  overview: string
  number_of_seasons: number
  number_of_episodes: number
  created_by: { id: number; name: string }[]
  external_ids?: {
    imdb_id: string
    tvdb_id: number
    tvrage_id: number
  }
}

interface Season {
  id: number
  name: string
  poster_path: string
  episode_count: number
  season_number: number
  overview: string
}

interface SeriesDetails {
  series: Series | null
  seasons: Season[]
  recommendations: any[]
}

export default function SeriesDetailPage({ params }: { params: { id: string } }) {
  const [seriesDetails, setSeriesDetails] = useState<SeriesDetails>({
    series: null,
    seasons: [],
    recommendations: [],
  })
  const [searchResults, setSearchResults] = useState([])
  const [showSearchResults, setShowSearchResults] = useState(false)
  const [expandedSeason, setExpandedSeason] = useState<number | null>(null)
  const [currentSeason, setCurrentSeason] = useState<number | null>(null)

  const handleSearch = (query: string) => {
    if (!query.trim()) {
      setShowSearchResults(false)
      return
    }

    fetch(`https://api.themoviedb.org/3/search/tv?api_key=${API_KEY}&query=${query}&page=1&include_adult=false`)
      .then((res) => res.json())
      .then((data) => {
        setSearchResults(data.results)
        setShowSearchResults(true)
      })
  }

  useEffect(() => {
    // Store series ID in localStorage for compatibility
    localStorage.setItem("seriesId", params.id)

    // Fetch series details
    fetch(`https://api.themoviedb.org/3/tv/${params.id}?api_key=${API_KEY}&append_to_response=external_ids`)
      .then((res) => res.json())
      .then((data) => {
        setSeriesDetails((prev) => ({
          ...prev,
          series: data,
          seasons: data.seasons || [],
        }))

        // Fetch recommendations
        fetch(`https://api.themoviedb.org/3/tv/${params.id}/recommendations?api_key=${API_KEY}&page=1`)
          .then((res) => res.json())
          .then((data) => {
            const formattedRecommendations = data.results.map((item: any) => ({
              id: item.id,
              title: item.name,
              poster_path: item.poster_path,
              backdrop_path: item.backdrop_path,
              vote_average: item.vote_average,
              release_date: item.first_air_date,
              overview: item.overview,
            }))

            setSeriesDetails((prev) => ({
              ...prev,
              recommendations: formattedRecommendations,
            }))
          })
      })
  }, [params.id])

  useEffect(() => {
    // Add scroll event listener for header background
    const handleScroll = () => {
      const header = document.querySelector(".header")
      if (window.scrollY > 50) {
        header?.classList.add("scrolled")
      } else {
        header?.classList.remove("scrolled")
      }
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const toggleSeason = (seasonNumber: number) => {
    if (expandedSeason === seasonNumber) {
      setExpandedSeason(null)
    } else {
      setExpandedSeason(seasonNumber)
    }
  }

  const handleWatchSeries = (seasonNumber = 1, episodeNumber = 1) => {
    const { series } = seriesDetails
    if (!series) return

    // Store streaming sources with priority order
    const streamSources = {
      // Use IMDb ID if available (better compatibility with vidsrc)
      vidsrcNet: series.external_ids?.imdb_id
        ? `https://vidsrc.net/embed/tv/${series.external_ids.imdb_id}/${seasonNumber}/${episodeNumber}`
        : `https://vidsrc.net/embed/tv/${params.id}/${seasonNumber}/${episodeNumber}`,
      vidsrcTo: series.external_ids?.imdb_id
        ? `https://vidsrc.to/embed/tv/${series.external_ids.imdb_id}/${seasonNumber}/${episodeNumber}`
        : `https://vidsrc.to/embed/tv/${params.id}/${seasonNumber}/${episodeNumber}`,
      vidsrcMe: series.external_ids?.imdb_id
        ? `https://vidsrc.me/embed/tv?imdb=${series.external_ids.imdb_id}&season=${seasonNumber}&episode=${episodeNumber}`
        : `https://vidsrc.me/embed/tv?tmdb=${params.id}&season=${seasonNumber}&episode=${episodeNumber}`,
      vidsrcXyz: `https://vidsrc.xyz/embed/tv/${params.id}/${seasonNumber}/${episodeNumber}`,
    }

    // Store the primary streaming URL and backup options
    localStorage.setItem("streamURL", streamSources.vidsrcNet)
    localStorage.setItem("streamBackups", JSON.stringify(streamSources))
    localStorage.setItem("seriesTitle", series.name)
    localStorage.setItem("seasonNumber", seasonNumber.toString())
    localStorage.setItem("episodeNumber", episodeNumber.toString())
    localStorage.setItem("seriesId", params.id)
    localStorage.setItem("imdbId", series.external_ids?.imdb_id || "")

    // Navigate to the player page
    window.location.href = "/playmovie.html"
  }

  const { series, seasons, recommendations } = seriesDetails

  useEffect(() => {
    if (seasons.length > 0) {
      setCurrentSeason(seasons[0].season_number)
    }
  }, [seasons])

  const handleSeasonChange = (seasonNumber: number) => {
    setCurrentSeason(seasonNumber)
  }

  if (!series) {
    return (
      <div className="min-h-screen bg-[#141414] text-white flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-[#e50914] border-r-transparent rounded-full animate-spin"></div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-[#141414] text-white">
      {/* Splash Screen */}
      <SplashScreen />

      {/* Header */}
      <Header onSearch={handleSearch} searchResults={searchResults} showSearchResults={showSearchResults} />

      <main>
        {/* Backdrop Image */}
        <div
          className="backdrop-image absolute top-0 left-0 w-full h-screen max-h-[700px] bg-no-repeat bg-cover bg-center -z-10"
          style={{
            backgroundImage: `url(${IMAGE_BASE_URL}${series.backdrop_path ? "w1280" : "original"}${series.backdrop_path || series.poster_path})`,
          }}
        >
          <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#141414]/80 to-[#141414]"></div>
        </div>

        {/* Series Detail */}
        <div className="px-5 pt-[calc(70vh-100px)] md:px-6 lg:px-14">
          <div className="flex flex-col md:flex-row gap-6">
            <figure className="hidden md:block flex-shrink-0 w-[200px] lg:w-[300px] bg-[url('/poster-bg-icon.png')] bg-no-repeat bg-center bg-[#232323] rounded-lg overflow-hidden">
              <Image
                src={`${IMAGE_BASE_URL}w342${series.poster_path}`}
                alt={`${series.name} poster`}
                width={342}
                height={513}
                className="w-full h-full object-cover"
              />
            </figure>

            <div className="flex-grow">
              <h1 className="text-3xl md:text-5xl font-bold mb-3">{series.name}</h1>

              <div className="flex flex-wrap items-center gap-3">
                <div className="flex items-center gap-1">
                  <Image
                    src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/star-Ur3y3uBQbLEILzAAVhz4I8s2FidNxU.png"
                    width={20}
                    height={20}
                    alt="rating"
                  />
                  <span>{series.vote_average.toFixed(1)}</span>
                </div>
                <div className="w-1 h-1 bg-white/20 rounded-full"></div>
                <div>{series.first_air_date?.split("-")[0] || "Not Released"}</div>
                <div className="w-1 h-1 bg-white/20 rounded-full"></div>
                <div>
                  {series.number_of_seasons} Season{series.number_of_seasons !== 1 ? "s" : ""}
                </div>
                <div className="w-1 h-1 bg-white/20 rounded-full"></div>
                <div>
                  {series.number_of_episodes} Episode{series.number_of_episodes !== 1 ? "s" : ""}
                </div>
              </div>

              <p className="text-[#b3b3b3] my-3">{series.genres.map((genre) => genre.name).join(", ")}</p>

              <p className="mb-6">{series.overview}</p>

              <div className="flex gap-3 mb-6">
                <button
                  onClick={() => handleWatchSeries()}
                  className="bg-[#e50914] hover:bg-[#f40612] px-5 py-3 rounded flex items-center gap-3 font-bold transition-colors"
                >
                  <Image
                    src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/play_circle-jTQ7UDufuUKCyyY7c44MHWDY2x2cJQ.png"
                    width={24}
                    height={24}
                    alt="play"
                  />
                  <span>Watch Now</span>
                </button>

                <button className="bg-white/10 hover:bg-white/20 px-5 py-3 rounded font-bold transition-colors">
                  <span>My List</span>
                </button>
              </div>

              <ul className="space-y-3 mb-8">
                <li className="flex flex-col sm:flex-row sm:gap-2">
                  <p className="text-[#b3b3b3] min-w-[112px]">Created By</p>
                  <p>{series.created_by?.map((creator) => creator.name).join(", ") || "Unknown"}</p>
                </li>
              </ul>
            </div>
          </div>

          {/* Seasons */}
          <section className="mt-8 mb-12">
            <h2 className="text-2xl font-bold mb-4">Seasons</h2>
            <select
              value={currentSeason}
              onChange={(e) => handleSeasonChange(Number.parseInt(e.target.value))}
              className="w-full bg-[#232323] text-white p-2 rounded-md mb-4"
            >
              {seasons.map((season) => (
                <option key={season.id} value={season.season_number}>
                  {season.name} ({season.episode_count} episodes)
                </option>
              ))}
            </select>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {seasons.map((season) => (
                <div key={season.id} className="bg-[#181818] rounded-lg overflow-hidden">
                  <div className="relative cursor-pointer" onClick={() => toggleSeason(season.season_number)}>
                    <div className="aspect-[2/3] relative">
                      <Image
                        src={
                          season.poster_path
                            ? `${IMAGE_BASE_URL}w342${season.poster_path}`
                            : "/placeholder.svg?height=300&width=200"
                        }
                        alt={season.name}
                        fill
                        className="object-cover"
                      />
                    </div>
                    <div className="absolute bottom-0 left-0 right-0 p-3 bg-gradient-to-t from-black/80 to-transparent">
                      <h3 className="font-bold">{season.name}</h3>
                      <p className="text-sm text-[#b3b3b3]">{season.episode_count} Episodes</p>
                    </div>
                  </div>

                  {expandedSeason === season.season_number && (
                    <div className="p-4">
                      <p className="text-sm mb-4">
                        {season.overview || `Season ${season.season_number} of ${series.name}.`}
                      </p>
                      <button
                        onClick={() => handleWatchSeries(season.season_number, 1)}
                        className="bg-[#e50914] text-white px-4 py-2 rounded-sm w-full"
                      >
                        Watch Season
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </section>

          {/* Recommendations */}
          {recommendations.length > 0 && (
            <section className="mb-8">
              <div className="mb-4">
                <h3 className="text-2xl font-bold text-white">More Like This</h3>
              </div>

              <div className="-mx-5 overflow-x-auto pb-4 scrollbar-hide">
                <div className="flex gap-2 px-5">
                  {recommendations.map((item) => (
                    <div
                      key={item.id}
                      className="min-w-[140px] rounded-lg overflow-hidden transition-transform duration-300 hover:scale-105 shadow-lg"
                    >
                      <Link href={`/series/${item.id}`}>
                        <div className="relative aspect-[2/3] w-[140px]">
                          <Image
                            src={`${IMAGE_BASE_URL}w342${item.poster_path}`}
                            alt={item.title}
                            fill
                            className="object-cover"
                          />
                        </div>
                        <div className="p-2 bg-[#181818]">
                          <h4 className="text-sm font-medium truncate">{item.title}</h4>
                          <div className="flex items-center gap-1 mt-1">
                            <Image
                              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/star-Ur3y3uBQbLEILzAAVhz4I8s2FidNxU.png"
                              width={12}
                              height={12}
                              alt="rating"
                            />
                            <span className="text-xs">{item.vote_average.toFixed(1)}</span>
                          </div>
                        </div>
                      </Link>
                    </div>
                  ))}
                </div>
              </div>
            </section>
          )}
        </div>
      </main>

      {/* Bottom Navigation */}
      <BottomNav />
    </div>
  )
}

