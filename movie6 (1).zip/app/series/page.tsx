"use client"

import { useEffect, useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { Header } from "../components/header"
import { BottomNav } from "../components/bottom-nav"
import { SplashScreen } from "../components/splash-screen"
import { ChevronRight } from "lucide-react"

// API configuration
const API_KEY = "7a5cf3c679b58ed507187030e928245a"
const IMAGE_BASE_URL = "https://image.tmdb.org/t/p/"

interface Series {
  id: number
  name: string
  poster_path: string
  backdrop_path: string
  vote_average: number
  first_air_date: string
  overview: string
  genre_ids: number[]
}

interface Genre {
  id: number
  name: string
}

export default function SeriesPage() {
  const [popularSeries, setPopularSeries] = useState<Series[]>([])
  const [topRatedSeries, setTopRatedSeries] = useState<Series[]>([])
  const [trendingSeries, setTrendingSeries] = useState<Series[]>([])
  const [genres, setGenres] = useState<{ [key: number]: string }>({})
  const [searchResults, setSearchResults] = useState<Series[]>([])
  const [showSearchResults, setShowSearchResults] = useState(false)
  const [featuredSeries, setFeaturedSeries] = useState<Series | null>(null)

  useEffect(() => {
    // Set document title
    document.title = "MOKEN - TV Series"

    // Fetch genres
    fetch(`https://api.themoviedb.org/3/genre/tv/list?api_key=${API_KEY}`)
      .then((res) => res.json())
      .then((data) => {
        const genreMap: { [key: number]: string } = {}
        data.genres.forEach((genre: Genre) => {
          genreMap[genre.id] = genre.name
        })
        setGenres(genreMap)
      })

    // Fetch popular series
    fetch(`https://api.themoviedb.org/3/tv/popular?api_key=${API_KEY}&page=1`)
      .then((res) => res.json())
      .then((data) => {
        setPopularSeries(data.results)
        // Set the first popular series as featured
        if (data.results.length > 0) {
          setFeaturedSeries(data.results[0])
        }
      })

    // Fetch top rated series
    fetch(`https://api.themoviedb.org/3/tv/top_rated?api_key=${API_KEY}&page=1`)
      .then((res) => res.json())
      .then((data) => setTopRatedSeries(data.results))

    // Fetch trending series
    fetch(`https://api.themoviedb.org/3/trending/tv/week?api_key=${API_KEY}&page=1`)
      .then((res) => res.json())
      .then((data) => setTrendingSeries(data.results))
  }, [])

  const handleSearch = (query: string) => {
    if (!query.trim()) {
      setShowSearchResults(false)
      return
    }

    fetch(`https://api.themoviedb.org/3/search/tv?api_key=${API_KEY}&query=${query}&page=1&include_adult=false`)
      .then((res) => res.json())
      .then((data) => {
        setSearchResults(data.results)
        setShowSearchResults(true)
      })
  }

  const getGenreString = (genreIds: number[]) => {
    return genreIds
      .map((id) => genres[id])
      .filter(Boolean)
      .join(", ")
  }

  const handleSeriesClick = (seriesId: number) => {
    localStorage.setItem("seriesId", seriesId.toString())
  }

  return (
    <div className="min-h-screen bg-[#141414] text-white">
      {/* Splash Screen */}
      <SplashScreen />

      {/* Header */}
      <Header onSearch={handleSearch} searchResults={searchResults} showSearchResults={showSearchResults} />

      <main className="pt-16 pb-20">
        {/* Search Results */}
        {showSearchResults && (
          <div className="search-modal fixed inset-0 bg-[#141414] pt-20 px-5 pb-5 overflow-y-auto z-40">
            <p className="text-[#e50914] font-bold text-sm mb-2">Results for</p>
            <h1 className="text-3xl font-bold mb-6">TV Series</h1>

            <div className="movie-list">
              <div className="grid-list grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
                {searchResults.map((series) => (
                  <SeriesCard key={series.id} series={series} onClick={handleSeriesClick} />
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Featured Series */}
        {featuredSeries && (
          <section className="relative h-[80vh] max-h-[700px] min-h-[450px] mb-10 overflow-hidden">
            <div className="absolute inset-0">
              <Image
                src={`${IMAGE_BASE_URL}w1280${featuredSeries.backdrop_path || featuredSeries.poster_path}`}
                alt={featuredSeries.name}
                fill
                className="object-cover"
                priority
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent"></div>
            </div>

            <div className="absolute left-5 right-5 bottom-[50px] md:left-[50px] md:right-auto md:max-w-[500px] z-10">
              <h2 className="text-3xl md:text-5xl font-bold mb-2 line-clamp-2">{featuredSeries.name}</h2>

              <div className="flex flex-wrap items-center gap-3 mb-2">
                <div>{featuredSeries.first_air_date?.split("-")[0] || "Not Released"}</div>
                <div className="bg-[#e5b80b] text-black text-xs font-bold px-1.5 rounded">
                  {featuredSeries.vote_average.toFixed(1)}
                </div>
              </div>

              <p className="text-[#b3b3b3] mb-2">{getGenreString(featuredSeries.genre_ids)}</p>

              <p className="text-[#b3b3b3] mb-4 line-clamp-2">{featuredSeries.overview}</p>

              <div className="flex gap-3">
                <Link
                  href={`/series/${featuredSeries.id}`}
                  className="bg-[#e50914] hover:bg-[#f40612] px-5 py-3 rounded flex items-center gap-3 font-bold transition-colors"
                  onClick={() => handleSeriesClick(featuredSeries.id)}
                >
                  <Image
                    src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/play_circle-jTQ7UDufuUKCyyY7c44MHWDY2x2cJQ.png"
                    width={24}
                    height={24}
                    alt="play"
                  />
                  <span>Play</span>
                </Link>

                <button className="bg-white/10 hover:bg-white/20 px-5 py-3 rounded font-bold transition-colors">
                  <span>My List</span>
                </button>
              </div>
            </div>
          </section>
        )}

        {/* Series Lists */}
        <SeriesList title="Popular Series" series={popularSeries} onSeriesClick={handleSeriesClick} />
        <SeriesList title="Trending Series" series={trendingSeries} onSeriesClick={handleSeriesClick} />
        <SeriesList title="Top Rated Series" series={topRatedSeries} onSeriesClick={handleSeriesClick} />

        {/* Genres Section */}
        <section className="px-5 py-8">
          <h2 className="text-2xl font-bold mb-6">Browse by Genre</h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
            {Object.entries(genres)
              .slice(0, 10)
              .map(([id, name]) => (
                <Link
                  key={id}
                  href={`/series/genre/${id}`}
                  className="bg-[#232323] hover:bg-[#333333] transition-colors p-4 rounded-md text-center"
                >
                  {name}
                </Link>
              ))}
          </div>
        </section>
      </main>

      {/* Bottom Navigation */}
      <BottomNav />
    </div>
  )
}

interface SeriesListProps {
  title: string
  series: Series[]
  onSeriesClick: (id: number) => void
}

function SeriesList({ title, series, onSeriesClick }: SeriesListProps) {
  if (!series.length) return null

  return (
    <section className="px-5 mb-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-2xl font-bold text-white">{title}</h3>
        <Link href="#" className="text-sm flex items-center gap-1 text-[#b3b3b3] hover:text-white">
          See All <ChevronRight size={16} />
        </Link>
      </div>

      <div className="-mx-5 overflow-x-auto pb-4 scrollbar-hide">
        <div className="flex gap-2 px-5">
          {series.map((item) => (
            <SeriesCard key={item.id} series={item} onClick={onSeriesClick} />
          ))}
        </div>
      </div>
    </section>
  )
}

interface SeriesCardProps {
  series: Series
  onClick: (id: number) => void
}

function SeriesCard({ series, onClick }: SeriesCardProps) {
  return (
    <div className="min-w-[140px] rounded-lg overflow-hidden transition-transform duration-300 hover:scale-105 shadow-[0_2px_10px_rgba(0,0,0,0.5)]">
      <Link href={`/series/${series.id}`} onClick={() => onClick(series.id)}>
        <div className="relative aspect-[2/3] w-[140px]">
          <Image
            src={
              series.poster_path
                ? `${IMAGE_BASE_URL}w342${series.poster_path}`
                : "/placeholder.svg?height=210&width=140"
            }
            alt={series.name}
            fill
            className="object-cover"
          />
        </div>
        <div className="absolute bottom-0 left-0 w-full p-2 bg-gradient-to-t from-black/80 to-transparent">
          <h4 className="text-sm font-medium truncate">{series.name}</h4>
          <div className="flex items-center gap-1 mt-1">
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/star-Ur3y3uBQbLEILzAAVhz4I8s2FidNxU.png"
              width={12}
              height={12}
              alt="rating"
            />
            <span className="text-xs">{series.vote_average.toFixed(1)}</span>
          </div>
        </div>
      </Link>
    </div>
  )
}

