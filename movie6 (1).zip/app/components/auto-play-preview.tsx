"use client"

import { useState, useEffect, useRef } from "react"
import { Volume2, VolumeX } from "lucide-react"

interface AutoPlayPreviewProps {
  movie: {
    id: number
    title: string
    backdrop_path: string
    overview: string
  }
  onClose: () => void
}

export function AutoPlayPreview({ movie, onClose }: AutoPlayPreviewProps) {
  const [isMuted, setIsMuted] = useState(true)
  const [isLoaded, setIsLoaded] = useState(false)
  const videoRef = useRef<HTMLVideoElement>(null)

  // Sample video URLs - in a real app, you would fetch these from your API
  const videoSources = [
    "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
    "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
    "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
    "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
    "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4",
    "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4",
  ]

  // Select a random video source based on movie ID
  const videoSource = videoSources[movie.id % videoSources.length]

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoaded(true)
      if (videoRef.current) {
        videoRef.current.play().catch((error) => {
          console.error("Auto-play was prevented:", error)
        })
      }
    }, 1000)

    return () => clearTimeout(timer)
  }, [])

  const toggleMute = () => {
    setIsMuted(!isMuted)
  }

  return (
    <div className="absolute inset-0 bg-black z-10 rounded-lg overflow-hidden">
      {!isLoaded && (
        <div className="absolute inset-0 flex items-center justify-center bg-black">
          <div className="w-12 h-12 border-4 border-[#e50914] border-t-transparent rounded-full animate-spin"></div>
        </div>
      )}

      <video
        ref={videoRef}
        src={videoSource}
        className="w-full h-full object-cover"
        autoPlay
        loop
        muted={isMuted}
        playsInline
      />

      <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/90 to-transparent">
        <h3 className="text-lg font-bold mb-1">{movie.title}</h3>
        <p className="text-sm text-gray-300 line-clamp-2 mb-3">{movie.overview}</p>

        <div className="flex items-center justify-between">
          <button
            className="bg-white text-black px-4 py-1 rounded-sm font-bold flex items-center gap-2"
            onClick={onClose}
          >
            <span>▶</span> Play
          </button>

          <button className="bg-gray-500/40 p-2 rounded-full" onClick={toggleMute}>
            {isMuted ? <VolumeX size={20} /> : <Volume2 size={20} />}
          </button>
        </div>
      </div>

      <button
        className="absolute top-2 right-2 bg-black/60 text-white w-8 h-8 rounded-full flex items-center justify-center"
        onClick={onClose}
      >
        ✕
      </button>
    </div>
  )
}

