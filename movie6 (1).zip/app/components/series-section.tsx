"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { MovieCard } from "./movie-card"
import { ChevronRight } from "lucide-react"

interface Series {
  id: number
  name: string
  poster_path: string
  backdrop_path: string
  vote_average: number
  first_air_date: string
  overview: string
}

export function SeriesSection() {
  const [series, setSeries] = useState<Series[]>([])
  const API_KEY = "7a5cf3c679b58ed507187030e928245a"

  useEffect(() => {
    // Fetch popular TV series
    fetch(`https://api.themoviedb.org/3/tv/popular?api_key=${API_KEY}&page=1`)
      .then((res) => res.json())
      .then((data) => {
        // Convert TV series data to match movie data structure
        const formattedSeries = data.results.map((item: any) => ({
          id: item.id,
          title: item.name,
          poster_path: item.poster_path,
          backdrop_path: item.backdrop_path,
          vote_average: item.vote_average,
          release_date: item.first_air_date,
          overview: item.overview,
        }))
        setSeries(formattedSeries)
      })
  }, [])

  const handleSeriesClick = (id: number) => {
    localStorage.setItem("seriesId", id.toString())
  }

  if (!series.length) return null

  return (
    <section className="px-5 mb-6">
      <div className="title-wrapper flex items-center justify-between mb-4">
        <h3 className="title-large text-2xl font-bold text-white">Popular Series</h3>
        <Link href="/series" className="see-all text-sm flex items-center gap-1 text-[#b3b3b3] hover:text-white">
          See All <ChevronRight size={16} />
        </Link>
      </div>

      <div className="slider-list -mx-5 overflow-x-auto pb-4 mb-6 scrollbar-hide">
        <div className="slider-inner flex gap-2 px-5 relative">
          {series.map((item) => (
            <MovieCard key={item.id} movie={item} onClick={handleSeriesClick} />
          ))}
        </div>
      </div>
    </section>
  )
}

