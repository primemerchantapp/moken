interface NetflixLogoProps {
  size?: "small" | "medium" | "large"
}

export function NetflixLogo({ size = "medium" }: NetflixLogoProps) {
  const sizeClasses = {
    small: "w-20 h-6",
    medium: "w-32 h-10",
    large: "w-64 h-20",
  }

  const textSizes = {
    small: "text-lg",
    medium: "text-3xl",
    large: "text-5xl",
  }

  return (
    <div className={`netflix-style-logo ${sizeClasses[size]} bg-[#e50914] flex items-center justify-center rounded-sm`}>
      <h1
        className={`text-white ${textSizes[size]} font-extrabold tracking-tighter`}
        style={{
          fontFamily: "Helvetica, Roboto, Arial, sans-serif",
          letterSpacing: "-1px",
          textShadow: "2px 2px 4px rgba(0, 0, 0, 0.5)",
        }}
      >
        MOKEN
      </h1>
    </div>
  )
}

