"use client"

import { useState, useEffect } from "react"
import { NetflixLogo } from "./netflix-logo"

export function SplashScreen() {
  const [show, setShow] = useState(true)

  useEffect(() => {
    const timer = setTimeout(() => {
      setShow(false)
    }, 2500)

    return () => clearTimeout(timer)
  }, [])

  if (!show) return null

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black">
      <div className="flex flex-col items-center">
        <NetflixLogo size="large" />
        <div className="mt-8 w-16 h-16 border-4 border-[#e50914] border-t-transparent rounded-full animate-spin"></div>
      </div>
    </div>
  )
}

