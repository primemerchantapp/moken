"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Search, Menu, X, User } from "lucide-react"
import { NetflixLogo } from "./netflix-logo"
import { useAuthState } from "@/hooks/use-auth"
import Image from "next/image"

interface HeaderProps {
  onSearch: (query: string) => void
  searchResults: any[]
  showSearchResults: boolean
}

export function Header({ onSearch, searchResults, showSearchResults }: HeaderProps) {
  const [searchOpen, setSearchOpen] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")
  const [isSearching, setIsSearching] = useState(false)
  const { user, isAuthenticated } = useAuthState()

  useEffect(() => {
    // Add scroll event listener for header background
    const handleScroll = () => {
      const header = document.querySelector(".header")
      if (window.scrollY > 50) {
        header?.classList.add("scrolled")
      } else {
        header?.classList.remove("scrolled")
      }
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  useEffect(() => {
    let searchTimeout: NodeJS.Timeout

    if (searchQuery.trim()) {
      setIsSearching(true)
      clearTimeout(searchTimeout)

      searchTimeout = setTimeout(() => {
        onSearch(searchQuery)
        setIsSearching(false)
      }, 500)
    }

    return () => clearTimeout(searchTimeout)
  }, [searchQuery, onSearch])

  return (
    <header className="header fixed top-0 left-0 w-full px-5 py-4 flex justify-between items-center z-50 transition-colors duration-300 bg-gradient-to-b from-black/70 to-transparent">
      <Link href="/" className="logo">
        <NetflixLogo size="small" />
      </Link>

      <div className="flex items-center gap-4">
        {searchOpen ? (
          <div className="search-box flex items-center gap-2 flex-1 max-w-md">
            <div className="search-wrapper relative flex-grow">
              <input
                type="text"
                placeholder="Search any movies..."
                className={`search-field w-full h-12 px-11 py-2 bg-[#181818] rounded text-white outline-none transition-all ${
                  isSearching ? "searching" : ""
                }`}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <Search className="absolute top-3 left-3 w-5 h-5 opacity-50" />
              {isSearching && (
                <div className="absolute top-3 right-3 w-5 h-5 border-2 border-white border-r-transparent rounded-full animate-spin"></div>
              )}
            </div>
            <button
              className="search-btn p-2"
              onClick={() => {
                setSearchOpen(false)
                setSearchQuery("")
                onSearch("")
              }}
            >
              <X className="w-6 h-6 opacity-80 hover:opacity-100 transition-opacity" />
            </button>
          </div>
        ) : (
          <button className="search-btn p-2" onClick={() => setSearchOpen(true)}>
            <Search className="w-6 h-6 opacity-80 hover:opacity-100 transition-opacity" />
          </button>
        )}

        <Link href="/profile" className="flex items-center">
          {isAuthenticated && user ? (
            <div className="relative w-8 h-8 rounded-full overflow-hidden">
              <Image
                src={user.avatar || "/placeholder.svg?height=32&width=32"}
                alt="Profile"
                width={32}
                height={32}
                className="object-cover"
              />
            </div>
          ) : (
            <User className="w-6 h-6 opacity-80 hover:opacity-100 transition-opacity" />
          )}
        </Link>

        <button className="menu-btn p-2 ml-2 lg:hidden">
          <Menu className="w-6 h-6 opacity-80 hover:opacity-100 transition-opacity" />
        </button>
      </div>
    </header>
  )
}

