"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"

interface Movie {
  id: number
  title: string
  backdrop_path: string
  poster_path: string
  vote_average: number
  release_date: string
  genre_ids: number[]
  overview: string
}

interface BannerSliderProps {
  movies: Movie[]
  genres: { [key: number]: string }
  onMovieClick: (id: number) => void
}

export function BannerSlider({ movies, genres, onMovieClick }: BannerSliderProps) {
  const [activeSlide, setActiveSlide] = useState(0)

  // Auto-rotate slides every 5 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      setActiveSlide((prev) => (prev + 1) % movies.length)
    }, 5000)
    return () => clearInterval(interval)
  }, [movies.length])

  const getGenreString = (genreIds: number[]) => {
    return genreIds
      .map((id) => genres[id])
      .filter(Boolean)
      .join(", ")
  }

  // Use the Puss in Boots images for the first two slides if available
  const getBackdropPath = (index: number, backdrop_path: string, poster_path: string) => {
    if (index === 0)
      return "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/slider-banner.jpg-PwfM5Ql8Rbcu13F0LQ2fDU9Ed5mXHc.jpeg"
    if (index === 1)
      return "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/slider-control.jpg-cahN5AvXIgK6FHJAiU2Hj1H4kcfTnP.jpeg"
    return `https://image.tmdb.org/t/p/w1280${backdrop_path || poster_path}`
  }

  return (
    <section className="banner relative h-[80vh] max-h-[700px] min-h-[450px] mb-10 overflow-hidden">
      {movies.map((movie, index) => (
        <div
          key={movie.id}
          className={`slider-item absolute top-0 w-full h-full bg-[#181818] transition-opacity duration-500 ${
            index === activeSlide ? "left-0 opacity-100 visible" : "left-[120%] opacity-0 invisible"
          }`}
        >
          <Image
            src={getBackdropPath(index, movie.backdrop_path, movie.poster_path) || "/placeholder.svg"}
            alt={movie.title}
            fill
            className="object-cover"
            priority={index === 0}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent"></div>

          <div className="banner-content absolute left-5 right-5 bottom-[50px] md:left-[50px] md:right-auto md:max-w-[500px] z-10">
            <h2 className="heading text-3xl md:text-5xl font-bold mb-2 line-clamp-2">{movie.title}</h2>

            <div className="meta-list flex flex-wrap items-center gap-3 mb-2">
              <div className="meta-item">{movie.release_date?.split("-")[0] || "Not Released"}</div>
              <div className="meta-item card-badge bg-[#e5b80b] text-black text-xs font-bold px-1.5 rounded">
                {movie.vote_average.toFixed(1)}
              </div>
            </div>

            <p className="genre text-[#b3b3b3] mb-2">{getGenreString(movie.genre_ids)}</p>

            <p className="banner-text text-[#b3b3b3] mb-4 line-clamp-2">{movie.overview}</p>

            <div className="banner-actions flex gap-3">
              <Link
                href={`/detail/${movie.id}`}
                className="btn btn-primary bg-[#e50914] hover:bg-[#f40612] px-5 py-3 rounded flex items-center gap-3 font-bold transition-colors"
                onClick={() => onMovieClick(movie.id)}
              >
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/play_circle-jTQ7UDufuUKCyyY7c44MHWDY2x2cJQ.png"
                  width={24}
                  height={24}
                  alt="play"
                />
                <span>Play</span>
              </Link>

              <button className="btn btn-secondary bg-white/10 hover:bg-white/20 px-5 py-3 rounded font-bold transition-colors">
                <span>My List</span>
              </button>
            </div>
          </div>
        </div>
      ))}

      <div className="slider-control absolute bottom-5 left-0 right-0 flex justify-center gap-2 z-20">
        {movies.map((_, index) => (
          <button
            key={index}
            className={`w-2 h-2 rounded-full transition-all ${
              index === activeSlide ? "w-6 rounded bg-[#e50914]" : "bg-white/40"
            }`}
            onClick={() => setActiveSlide(index)}
          ></button>
        ))}
      </div>
    </section>
  )
}

