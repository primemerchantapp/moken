"use client"

import { useState, useRef } from "react"
import Image from "next/image"
import Link from "next/link"
import { AutoPlayPreview } from "./auto-play-preview"

interface Movie {
  id: number
  title: string
  poster_path: string
  backdrop_path: string
  vote_average: number
  overview: string
}

interface MovieCardProps {
  movie: Movie
  onClick?: (id: number) => void
}

export function MovieCard({ movie, onClick }: MovieCardProps) {
  const [showPreview, setShowPreview] = useState(false)
  const previewTimeoutRef = useRef<NodeJS.Timeout | null>(null)
  const IMAGE_BASE_URL = "https://image.tmdb.org/t/p/"

  const handleMouseEnter = () => {
    previewTimeoutRef.current = setTimeout(() => {
      setShowPreview(true)
    }, 800) // Delay before showing preview
  }

  const handleMouseLeave = () => {
    if (previewTimeoutRef.current) {
      clearTimeout(previewTimeoutRef.current)
      previewTimeoutRef.current = null
    }
    setShowPreview(false)
  }

  const handleMovieClick = () => {
    if (onClick) {
      onClick(movie.id)
    }
  }

  return (
    <div
      className="movie-card relative min-w-[140px] rounded-lg overflow-hidden transition-transform duration-300 hover:scale-105 shadow-[0_2px_10px_rgba(0,0,0,0.5)] z-0 hover:z-10"
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
    >
      <figure className="poster-box card-banner w-full h-[200px] bg-[url('/poster-bg-icon.png')] bg-no-repeat bg-center bg-[#232323]">
        <Image
          src={`${IMAGE_BASE_URL}w342${movie.poster_path}`}
          alt={movie.title}
          width={342}
          height={513}
          className="img-cover w-full h-full object-cover"
        />
      </figure>

      <h4 className="title absolute bottom-0 left-0 w-full p-2.5 bg-gradient-to-t from-black/80 to-transparent whitespace-nowrap overflow-hidden text-ellipsis text-sm">
        {movie.title}
      </h4>

      <div className="meta-list absolute top-2.5 right-2.5">
        <div className="meta-item flex items-center gap-1 bg-[#e5b80b] text-black text-xs font-bold px-1.5 rounded">
          <Image
            src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/star-Ur3y3uBQbLEILzAAVhz4I8s2FidNxU.png"
            width={16}
            height={16}
            alt="rating"
          />
          <span>{movie.vote_average.toFixed(1)}</span>
        </div>
      </div>

      <Link href={`/detail/${movie.id}`} className="card-btn absolute inset-0" onClick={handleMovieClick}>
        <span className="sr-only">{movie.title}</span>
      </Link>

      {/* Auto-play Preview */}
      {showPreview && (
        <div className="absolute top-0 left-0 w-[300px] h-auto z-20 shadow-xl transform -translate-x-[20%] scale-125">
          <AutoPlayPreview movie={movie} onClose={() => setShowPreview(false)} />
        </div>
      )}
    </div>
  )
}

