"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { User } from "lucide-react"

export function BottomNav() {
  const pathname = usePathname()

  return (
    <nav className="bottom-nav fixed bottom-0 left-0 w-full bg-[#141414] flex justify-around py-3 border-t border-[#232323] z-50 lg:hidden">
      <Link
        href="/"
        className={`bottom-nav-item flex flex-col items-center text-sm ${pathname === "/" ? "text-white" : "text-[#b3b3b3]"}`}
      >
        <span className="bottom-nav-icon text-2xl mb-1">🏠</span>
        <span>Home</span>
      </Link>
      <Link href="#" className="bottom-nav-item flex flex-col items-center text-[#b3b3b3] text-sm">
        <span className="bottom-nav-icon text-2xl mb-1">🎬</span>
        <span>Movies</span>
      </Link>
      <Link
        href="/music"
        className={`bottom-nav-item flex flex-col items-center text-sm ${pathname.startsWith("/music") ? "text-white" : "text-[#b3b3b3]"}`}
      >
        <span className="bottom-nav-icon text-2xl mb-1">🎵</span>
        <span>Music</span>
      </Link>
      <Link
        href="/series"
        className={`bottom-nav-item flex flex-col items-center text-sm ${pathname.startsWith("/series") ? "text-white" : "text-[#b3b3b3]"}`}
      >
        <span className="bottom-nav-icon text-2xl mb-1">📺</span>
        <span>TV Shows</span>
      </Link>
      <Link
        href="/profile"
        className={`bottom-nav-item flex flex-col items-center text-sm ${pathname.startsWith("/profile") ? "text-white" : "text-[#b3b3b3]"}`}
      >
        <span className="bottom-nav-icon">
          <User size={24} />
        </span>
        <span>Profile</span>
      </Link>
    </nav>
  )
}

