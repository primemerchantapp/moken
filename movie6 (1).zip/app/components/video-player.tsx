"use client"

import type React from "react"

import { useEffect, useState, useRef } from "react"
import Hls from "hls.js"
import { Play, Pause, Volume2, VolumeX, Maximize, SkipBack, SkipForward, Settings } from "lucide-react"

interface VideoPlayerProps {
  src: string
  title: string
  subtitle?: string
  onNext?: () => void
  onPrevious?: () => void
  poster?: string
  autoPlay?: boolean
}

export function VideoPlayer({ src, title, subtitle, onNext, onPrevious, poster, autoPlay = false }: VideoPlayerProps) {
  const [isPlaying, setIsPlaying] = useState(autoPlay)
  const [isMuted, setIsMuted] = useState(false)
  const [volume, setVolume] = useState(1)
  const [currentTime, setCurrentTime] = useState(0)
  const [duration, setDuration] = useState(0)
  const [isFullscreen, setIsFullscreen] = useState(false)
  const [showControls, setShowControls] = useState(true)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [quality, setQuality] = useState<string>("auto")
  const [availableQualities, setAvailableQualities] = useState<string[]>([])
  const [showSettings, setShowSettings] = useState(false)

  const videoRef = useRef<HTMLVideoElement>(null)
  const videoContainerRef = useRef<HTMLDivElement>(null)
  const controlsTimeoutRef = useRef<NodeJS.Timeout | null>(null)
  const hlsRef = useRef<Hls | null>(null)

  useEffect(() => {
    // Initialize HLS.js
    if (!videoRef.current) return

    const video = videoRef.current
    setIsLoading(true)
    setError(null)

    if (Hls.isSupported()) {
      const hls = new Hls({
        autoStartLoad: true,
        startLevel: -1, // Auto level selection
      })

      hlsRef.current = hls

      hls.loadSource(src)
      hls.attachMedia(video)

      hls.on(Hls.Events.MANIFEST_PARSED, (event, data) => {
        setIsLoading(false)

        // Get available qualities
        const levels = hls.levels.map((level) => `${level.height}p`)
        setAvailableQualities(["auto", ...levels])

        if (autoPlay) {
          video.play().catch((e) => {
            console.error("Auto play failed:", e)
            setIsPlaying(false)
          })
        }
      })

      hls.on(Hls.Events.ERROR, (event, data) => {
        console.error("HLS error:", data)
        if (data.fatal) {
          switch (data.type) {
            case Hls.ErrorTypes.NETWORK_ERROR:
              setError("Network error. Please check your connection and try again.")
              hls.startLoad()
              break
            case Hls.ErrorTypes.MEDIA_ERROR:
              setError("Media error. Trying to recover...")
              hls.recoverMediaError()
              break
            default:
              setError("Fatal error. Cannot play this video.")
              hls.destroy()
              break
          }
        }
      })

      return () => {
        hls.destroy()
      }
    } else if (video.canPlayType("application/vnd.apple.mpegurl")) {
      // For Safari
      video.src = src
      video.addEventListener("loadedmetadata", () => {
        setIsLoading(false)
        if (autoPlay) {
          video.play().catch((e) => {
            console.error("Auto play failed:", e)
            setIsPlaying(false)
          })
        }
      })

      video.addEventListener("error", () => {
        setError("Error loading video. Please try again later.")
        setIsLoading(false)
      })
    } else {
      setError("Your browser does not support HLS playback.")
      setIsLoading(false)
    }
  }, [src, autoPlay])

  const togglePlay = () => {
    if (!videoRef.current) return

    if (isPlaying) {
      videoRef.current.pause()
    } else {
      videoRef.current.play().catch((e) => console.error("Play failed:", e))
    }
    setIsPlaying(!isPlaying)
  }

  const toggleMute = () => {
    if (!videoRef.current) return

    videoRef.current.muted = !isMuted
    setIsMuted(!isMuted)
  }

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newVolume = Number.parseFloat(e.target.value)
    setVolume(newVolume)

    if (videoRef.current) {
      videoRef.current.volume = newVolume
      setIsMuted(newVolume === 0)
    }
  }

  const handleTimeUpdate = () => {
    if (!videoRef.current) return

    setCurrentTime(videoRef.current.currentTime)
    setDuration(videoRef.current.duration)
  }

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const seekTime = Number.parseFloat(e.target.value)
    setCurrentTime(seekTime)

    if (videoRef.current) {
      videoRef.current.currentTime = seekTime
    }
  }

  const toggleFullscreen = () => {
    if (!videoContainerRef.current) return

    if (!isFullscreen) {
      if (videoContainerRef.current.requestFullscreen) {
        videoContainerRef.current.requestFullscreen()
      }
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen()
      }
    }
  }

  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement)
    }

    document.addEventListener("fullscreenchange", handleFullscreenChange)

    return () => {
      document.removeEventListener("fullscreenchange", handleFullscreenChange)
    }
  }, [])

  const handleMouseMove = () => {
    setShowControls(true)

    if (controlsTimeoutRef.current) {
      clearTimeout(controlsTimeoutRef.current)
    }

    controlsTimeoutRef.current = setTimeout(() => {
      if (isPlaying) {
        setShowControls(false)
      }
    }, 3000)
  }

  const formatTime = (time: number) => {
    if (isNaN(time)) return "0:00"

    const minutes = Math.floor(time / 60)
    const seconds = Math.floor(time % 60)
    return `${minutes}:${seconds.toString().padStart(2, "0")}`
  }

  const handleQualityChange = (newQuality: string) => {
    if (!hlsRef.current) return

    const hls = hlsRef.current

    if (newQuality === "auto") {
      hls.currentLevel = -1 // Auto level
    } else {
      // Find the level that matches the selected quality
      const height = Number.parseInt(newQuality.replace("p", ""))
      const levelIndex = hls.levels.findIndex((level) => level.height === height)

      if (levelIndex !== -1) {
        hls.currentLevel = levelIndex
      }
    }

    setQuality(newQuality)
    setShowSettings(false)
  }

  return (
    <div ref={videoContainerRef} className="relative w-full h-full bg-black" onMouseMove={handleMouseMove}>
      <video
        ref={videoRef}
        className="w-full h-full object-contain"
        poster={poster}
        onTimeUpdate={handleTimeUpdate}
        onPlay={() => setIsPlaying(true)}
        onPause={() => setIsPlaying(false)}
        onEnded={() => onNext && onNext()}
        onClick={togglePlay}
      />

      {/* Loading Indicator */}
      {isLoading && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/50">
          <div className="w-12 h-12 border-4 border-[#e50914] border-r-transparent rounded-full animate-spin"></div>
        </div>
      )}

      {/* Error Message */}
      {error && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/80">
          <div className="bg-[#232323] p-4 rounded-md max-w-md text-center">
            <p className="text-red-500 mb-2">⚠️ {error}</p>
            <button onClick={() => window.location.reload()} className="bg-[#e50914] text-white px-4 py-2 rounded-md">
              Reload Player
            </button>
          </div>
        </div>
      )}

      {/* Video Controls */}
      {showControls && !error && (
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex flex-col justify-between p-4">
          {/* Top Controls */}
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-lg font-bold">{title}</h1>
              {subtitle && <p className="text-sm text-white/70">{subtitle}</p>}
            </div>
            <div>
              <button onClick={() => setShowSettings(!showSettings)} className="text-white/80 hover:text-white p-2">
                <Settings size={20} />
              </button>

              {/* Settings Menu */}
              {showSettings && (
                <div className="absolute top-12 right-4 bg-black/90 rounded-md p-2 z-10">
                  <div className="text-sm font-bold mb-1">Quality</div>
                  <div className="space-y-1">
                    {availableQualities.map((q) => (
                      <button
                        key={q}
                        onClick={() => handleQualityChange(q)}
                        className={`block w-full text-left px-2 py-1 rounded ${
                          quality === q ? "bg-[#e50914] text-white" : "hover:bg-white/10"
                        }`}
                      >
                        {q}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Center Play Button */}
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
            <button onClick={togglePlay} className="bg-white/20 hover:bg-white/30 rounded-full p-4 transition-colors">
              {isPlaying ? <Pause size={32} /> : <Play size={32} />}
            </button>
          </div>

          {/* Bottom Controls */}
          <div className="space-y-2">
            {/* Progress Bar */}
            <div className="flex items-center gap-2">
              <span className="text-sm">{formatTime(currentTime)}</span>
              <input
                type="range"
                min="0"
                max={duration || 100}
                value={currentTime}
                onChange={handleSeek}
                className="w-full h-1 bg-white/30 rounded-full appearance-none cursor-pointer"
                style={{
                  background: `linear-gradient(to right, #e50914 ${(currentTime / (duration || 1)) * 100}%, rgba(255, 255, 255, 0.3) ${(currentTime / (duration || 1)) * 100}%)`,
                }}
              />
              <span className="text-sm">{formatTime(duration)}</span>
            </div>

            {/* Control Buttons */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                {onPrevious && (
                  <button onClick={onPrevious} className="text-white/80 hover:text-white">
                    <SkipBack size={24} />
                  </button>
                )}
                <button onClick={togglePlay} className="text-white/80 hover:text-white">
                  {isPlaying ? <Pause size={24} /> : <Play size={24} />}
                </button>
                {onNext && (
                  <button onClick={onNext} className="text-white/80 hover:text-white">
                    <SkipForward size={24} />
                  </button>
                )}
                <div className="flex items-center gap-2">
                  <button onClick={toggleMute} className="text-white/80 hover:text-white">
                    {isMuted ? <VolumeX size={24} /> : <Volume2 size={24} />}
                  </button>
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.01"
                    value={isMuted ? 0 : volume}
                    onChange={handleVolumeChange}
                    className="w-20 h-1 bg-white/30 rounded-full appearance-none cursor-pointer"
                  />
                </div>
              </div>
              <button onClick={toggleFullscreen} className="text-white/80 hover:text-white">
                <Maximize size={24} />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

