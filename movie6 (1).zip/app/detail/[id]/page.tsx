"use client"

import { useEffect, useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { Header } from "../../components/header"
import { BottomNav } from "../../components/bottom-nav"
import { SplashScreen } from "../../components/splash-screen"

// API configuration
const IMAGE_BASE_URL = "https://media.themoviedb.org/t/p/"
const API_KEY = "7a5cf3c679b58ed507187030e928245a"

interface Movie {
  id: number
  title: string
  poster_path: string
  backdrop_path: string
  vote_average: number
  release_date: string
  runtime: number
  genres: { id: number; name: string }[]
  overview: string
  releases: {
    countries: { certification: string }[]
  }
  external_ids?: {
    imdb_id?: string
  }
}

interface Cast {
  id: number
  name: string
  character: string
  profile_path: string | null
}

interface Crew {
  id: number
  name: string
  job: string
}

interface Video {
  id: string
  key: string
  name: string
  site: string
  type: string
}

interface MovieDetails {
  movie: Movie | null
  cast: Cast[]
  crew: Crew[]
  videos: Video[]
  recommendations: Movie[]
}

export default function DetailPage({ params }: { params: { id: string } }) {
  const [movieDetails, setMovieDetails] = useState<MovieDetails>({
    movie: null,
    cast: [],
    crew: [],
    videos: [],
    recommendations: [],
  })
  const [searchOpen, setSearchOpen] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")
  const [searchResults, setSearchResults] = useState<Movie[]>([])
  const [isSearching, setIsSearching] = useState(false)
  const [showSearchResults, setShowSearchResults] = useState(false)

  const handleSearch = (query: string) => {
    if (!query.trim()) {
      setShowSearchResults(false)
      return
    }

    fetch(`https://api.themoviedb.org/3/search/movie?api_key=${API_KEY}&query=${query}&page=1&include_adult=false`)
      .then((res) => res.json())
      .then((data) => {
        setSearchResults(data.results)
        setShowSearchResults(true)
      })
  }

  useEffect(() => {
    // Store movie ID in localStorage for compatibility with original code
    localStorage.setItem("movieId", params.id)

    // Fetch movie details
    fetch(
      `https://api.themoviedb.org/3/movie/${params.id}?api_key=${API_KEY}&append_to_response=casts,videos,images,releases,external_ids`,
    )
      .then((res) => {
        if (!res.ok) {
          throw new Error(`TMDB API error: ${res.status} ${res.statusText}`)
        }
        return res.json()
      })
      .then((data) => {
        setMovieDetails((prev) => ({
          ...prev,
          movie: data,
          cast: data.casts?.cast || [],
          crew: data.casts?.crew || [],
          videos: filterVideos(data.videos?.results || []),
        }))

        // Fetch recommendations
        fetch(`https://api.themoviedb.org/3/movie/${params.id}/recommendations?api_key=${API_KEY}&page=1`)
          .then((res) => res.json())
          .then((data) => {
            setMovieDetails((prev) => ({
              ...prev,
              recommendations: data.results || [],
            }))
          })
      })
  }, [params.id])

  const { movie } = movieDetails

  // Special handling for movie ID 822119
  useEffect(() => {
    if (params.id === "822119" && movie) {
      console.log("Found movie 822119:", movie.title)
      console.log("Backdrop path:", movie.backdrop_path)
      console.log("Poster path:", movie.poster_path)
    }
  }, [params.id, movie])

  useEffect(() => {
    // Add scroll event listener for header background
    const handleScroll = () => {
      const header = document.querySelector(".header")
      if (window.scrollY > 50) {
        header?.classList.add("scrolled")
      } else {
        header?.classList.remove("scrolled")
      }
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  useEffect(() => {
    let searchTimeout: NodeJS.Timeout

    if (searchQuery.trim()) {
      setIsSearching(true)
      clearTimeout(searchTimeout)

      searchTimeout = setTimeout(() => {
        fetch(
          `https://api.themoviedb.org/3/search/movie?api_key=${API_KEY}&query=${searchQuery}&page=1&include_adult=false`,
        )
          .then((res) => res.json())
          .then((data) => {
            setSearchResults(data.results)
            setIsSearching(false)
            setShowSearchResults(true)
          })
      }, 500)
    } else {
      setShowSearchResults(false)
    }

    return () => clearTimeout(searchTimeout)
  }, [searchQuery])

  const filterVideos = (videoList: Video[]) => {
    return videoList.filter(({ type, site }) => (type === "Trailer" || type === "Teaser") && site === "YouTube")
  }

  const getCasts = (castList: Cast[]) => {
    const newCastList = []
    for (let i = 0, len = castList.length; i < len && i < 10; i++) {
      const { name } = castList[i]
      newCastList.push(name)
    }
    return newCastList.join(", ")
  }

  const getDirectors = (crewList: Crew[]) => {
    const directors = crewList.filter(({ job }) => job === "Director")
    const directorList = []
    for (const { name } of directors) directorList.push(name)
    return directorList.join(", ")
  }

  const handleStreamNow = () => {
    // Get IMDB ID if available, otherwise use TMDB ID
    const imdbId = movie.external_ids?.imdb_id
    const tmdbId = params.id

    // Create direct vidsrc URLs using the official API endpoints
    // Using multiple domains as specified in the documentation
    const streamSources = {
      vidsrcXyz: imdbId
        ? `https://vidsrc.xyz/embed/movie?imdb=${imdbId}`
        : `https://vidsrc.xyz/embed/movie?tmdb=${tmdbId}`,
      vidsrcNet: imdbId
        ? `https://vidsrc.net/embed/movie?imdb=${imdbId}`
        : `https://vidsrc.net/embed/movie?tmdb=${tmdbId}`,
      vidsrcIn: imdbId
        ? `https://vidsrc.in/embed/movie?imdb=${imdbId}`
        : `https://vidsrc.in/embed/movie?tmdb=${tmdbId}`,
      vidsrcPm: imdbId
        ? `https://vidsrc.pm/embed/movie?imdb=${imdbId}`
        : `https://vidsrc.pm/embed/movie?tmdb=${tmdbId}`,
    }

    // Store streaming URLs
    localStorage.setItem("streamURL", streamSources.vidsrcXyz) // Use vidsrc.xyz as primary
    localStorage.setItem("streamBackups", JSON.stringify(streamSources))
    localStorage.setItem("movieTitle", movie.title)
    localStorage.setItem("movieId", params.id)
    localStorage.setItem("imdbId", movie.external_ids?.imdb_id || "")
  }

  const { cast, crew, videos, recommendations } = movieDetails

  // Log the backdrop path for debugging
  useEffect(() => {
    if (movie) {
      console.log("Movie backdrop path:", movie.backdrop_path)
      console.log(
        "Full backdrop URL:",
        `${IMAGE_BASE_URL}${movie.backdrop_path ? "w1280" : "original"}${movie.backdrop_path || movie.poster_path}`,
      )
    }
  }, [movie])

  if (!movie) {
    return (
      <div className="min-h-screen bg-[#141414] text-white flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-[#e50914] border-r-transparent rounded-full animate-spin"></div>
      </div>
    )
  }

  const streamNowButton = (
    <Link
      href="/playmovie"
      className="btn btn-primary bg-[#e50914] hover:bg-[#f40612] px-5 py-3 rounded flex items-center gap-3 font-bold transition-colors"
      onClick={handleStreamNow}
    >
      <Image
        src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/play_circle-jTQ7UDufuUKCyyY7c44MHWDY2x2cJQ.png"
        width={24}
        height={24}
        alt="stream"
      />
      <span>Play</span>
    </Link>
  )

  return (
    <div className="min-h-screen bg-[#141414] text-white">
      {/* Splash Screen */}
      <SplashScreen />

      {/* Header */}
      <Header onSearch={handleSearch} searchResults={searchResults} showSearchResults={showSearchResults} />

      <main>
        {/* Search Results */}
        {showSearchResults && (
          <div className="search-modal fixed inset-0 bg-[#141414] pt-20 px-5 pb-5 overflow-y-auto z-40">
            <p className="text-[#e50914] font-bold text-sm mb-2">Results for</p>
            <h1 className="text-3xl font-bold mb-6">{searchQuery}</h1>

            <div className="movie-list">
              <div className="grid-list grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
                {searchResults.map((movie) => (
                  <MovieCard key={movie.id} movie={movie} />
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Backdrop Image */}
        <div
          className="absolute top-0 left-0 w-full h-[70vh] bg-no-repeat bg-cover bg-center -z-10"
          style={{
            backgroundImage:
              movie.backdrop_path || movie.poster_path
                ? `url(https://media.themoviedb.org/t/p/w1280${movie.backdrop_path || movie.poster_path})`
                : "linear-gradient(to bottom, #333, #141414)",
          }}
        >
          <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#141414]/70 to-[#141414]"></div>
        </div>

        {/* Movie Detail */}
        <div className="movie-detail px-5 pt-[60vh] md:px-6 lg:px-14">
          <div className="detail-box flex flex-col md:flex-row gap-6">
            <figure className="poster-box movie-poster hidden md:block flex-shrink-0 w-[200px] lg:w-[300px] bg-[url('/poster-bg-icon.png')] bg-no-repeat bg-center bg-[#232323] rounded-lg overflow-hidden">
              <Image
                src={`${IMAGE_BASE_URL}w342${movie.poster_path}`}
                alt={`${movie.title} poster`}
                width={342}
                height={513}
                className="img-cover w-full h-full object-cover"
                onError={(e) => {
                  // Fallback if the image fails to load
                  const target = e.target as HTMLImageElement
                  target.src = "/placeholder.svg?height=513&width=342&text=No+Image"
                }}
              />
            </figure>

            <div className="detail-content flex-grow">
              <h1 className="heading text-3xl md:text-5xl font-bold mb-3">{movie.title}</h1>

              <div className="meta-list flex flex-wrap items-center gap-3">
                <div className="meta-item flex items-center gap-1">
                  <Image
                    src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/star-Ur3y3uBQbLEILzAAVhz4I8s2FidNxU.png"
                    width={20}
                    height={20}
                    alt="rating"
                  />
                  <span>{movie.vote_average.toFixed(1)}</span>
                </div>
                <div className="separator w-1 h-1 bg-white/20 rounded-full"></div>
                <div className="meta-item">{movie.runtime}m</div>
                <div className="separator w-1 h-1 bg-white/20 rounded-full"></div>
                <div className="meta-item">{movie.release_date?.split("-")[0] || "Not Released"}</div>
                <div className="meta-item card-badge bg-[#e5b80b] text-black text-xs font-bold px-1.5 rounded">
                  {movie.releases?.countries?.[0]?.certification || "N/A"}
                </div>
              </div>

              <p className="genre text-[#b3b3b3] my-3">{movie.genres.map((genre) => genre.name).join(", ")}</p>

              <p className="overview mb-6">{movie.overview}</p>

              <div className="detail-actions flex gap-3 mb-6">
                {streamNowButton}

                <button className="btn btn-secondary bg-white/10 hover:bg-white/20 px-5 py-3 rounded font-bold transition-colors">
                  <span>My List</span>
                </button>
              </div>

              <ul className="detail-list space-y-3 mb-8">
                <li className="list-item flex flex-col sm:flex-row sm:gap-2">
                  <p className="list-name text-[#b3b3b3] min-w-[112px]">Starring</p>
                  <p>{getCasts(cast)}</p>
                </li>
                <li className="list-item flex flex-col sm:flex-row sm:gap-2">
                  <p className="list-name text-[#b3b3b3] min-w-[112px]">Directed By</p>
                  <p>{getDirectors(crew)}</p>
                </li>
              </ul>
            </div>
          </div>

          {/* Trailers */}
          {videos.length > 0 && (
            <>
              <div className="title-wrapper mb-4">
                <h3 className="title-large text-2xl font-bold text-white">Trailers and More</h3>
              </div>
              <div className="slider-list -mx-5 overflow-x-auto pb-4 mb-6 scrollbar-hide">
                <div className="slider-inner flex gap-2 px-5">
                  {videos.map((video) => (
                    <div
                      key={video.id}
                      className="video-card flex-shrink-0 max-w-[500px] w-[calc(100%-40px)] aspect-video bg-[url('/video-bg-icon.png')] bg-no-repeat bg-center bg-[#232323] rounded-lg overflow-hidden"
                    >
                      <iframe
                        width="500"
                        height="294"
                        src={`https://www.youtube.com/embed/${video.key}?&theme=dark&color=white&rel=0`}
                        title={video.name}
                        className="w-full h-full"
                        frameBorder="0"
                        allowFullScreen
                      ></iframe>
                    </div>
                  ))}
                </div>
              </div>
            </>
          )}

          {/* Recommendations */}
          {recommendations.length > 0 && (
            <section className="movie-list mb-8">
              <div className="title-wrapper mb-4">
                <h3 className="title-large text-2xl font-bold text-white">More Like This</h3>
              </div>

              <div className="slider-list -mx-5 overflow-x-auto pb-4 scrollbar-hide">
                <div className="slider-inner flex gap-2 px-5">
                  {recommendations.map((movie) => (
                    <MovieCard key={movie.id} movie={movie} />
                  ))}
                </div>
              </div>
            </section>
          )}
        </div>
      </main>

      {/* Bottom Navigation */}
      <BottomNav />
    </div>
  )
}

interface MovieCardProps {
  movie: Movie
}

function MovieCard({ movie }: MovieCardProps) {
  const handleMovieClick = () => {
    localStorage.setItem("movieId", movie.id.toString())
  }

  return (
    <div className="movie-card relative min-w-[140px] rounded-lg overflow-hidden transition-transform duration-300 hover:scale-105 shadow-[0_2px_10px_rgba(0,0,0,0.5)]">
      <figure className="poster-box card-banner w-full h-[200px] bg-[url('/poster-bg-icon.png')] bg-no-repeat bg-center bg-[#232323]">
        <Image
          src={`${IMAGE_BASE_URL}w342${movie.poster_path}`}
          alt={movie.title}
          width={342}
          height={513}
          className="img-cover w-full h-full object-cover"
          onError={(e) => {
            // Fallback if the image fails to load
            const target = e.target as HTMLImageElement
            target.src = "/placeholder.svg?height=513&width=342&text=No+Image"
          }}
        />
      </figure>

      <h4 className="title absolute bottom-0 left-0 w-full p-2.5 bg-gradient-to-t from-black/80 to-transparent whitespace-nowrap overflow-hidden text-ellipsis text-sm">
        {movie.title}
      </h4>

      <div className="meta-list absolute top-2.5 right-2.5">
        <div className="meta-item flex items-center gap-1 bg-[#e5b80b] text-black text-xs font-bold px-1.5 rounded">
          <Image
            src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/star-Ur3y3uBQbLEILzAAVhz4I8s2FidNxU.png"
            width={16}
            height={16}
            alt="rating"
          />
          <span>{movie.vote_average.toFixed(1)}</span>
        </div>
      </div>

      <Link href={`/detail/${movie.id}`} className="card-btn absolute inset-0" onClick={handleMovieClick}>
        <span className="sr-only">{movie.title}</span>
      </Link>
    </div>
  )
}

