"use client"

import { useState } from "react"
import Image from "next/image"
import { X, Copy, Check, Twitter, Facebook, Mail, LinkIcon } from "lucide-react"

interface ReferralRewardsModalProps {
  onClose: () => void
  referralLink: string
}

export function ReferralRewardsModal({ onClose, referralLink }: ReferralRewardsModalProps) {
  const [copied, setCopied] = useState(false)
  const [activeTab, setActiveTab] = useState<"how-it-works" | "rewards" | "share">("how-it-works")

  const copyReferralLink = () => {
    navigator.clipboard.writeText(referralLink)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  // Define rewards per level
  const levelRewards = [
    { level: 1, percentage: "10%", description: "Direct referrals" },
    { level: 2, percentage: "7%", description: "Your referrals' referrals" },
    { level: 3, percentage: "5%", description: "3rd generation referrals" },
    { level: 4, percentage: "4%", description: "4th generation referrals" },
    { level: 5, percentage: "3%", description: "5th generation referrals" },
    { level: 6, percentage: "2%", description: "6th generation referrals" },
    { level: 7, percentage: "2%", description: "7th generation referrals" },
    { level: 8, percentage: "1%", description: "8th generation referrals" },
    { level: 9, percentage: "1%", description: "9th generation referrals" },
    { level: 10, percentage: "1%", description: "10th generation referrals" },
  ]

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4 overflow-y-auto">
      <div className="bg-[#181818] rounded-lg max-w-2xl w-full p-6 relative max-h-[90vh] overflow-y-auto">
        <button onClick={onClose} className="absolute top-4 right-4 text-[#b3b3b3] hover:text-white">
          <X size={24} />
        </button>

        <h2 className="text-2xl font-bold mb-6 text-center flex items-center justify-center gap-2">
          <Image
            src="/placeholder.svg?height=32&width=32&text=💰"
            width={32}
            height={32}
            alt="Rewards"
            className="rounded-full"
          />
          MOKEN Referral Rewards
        </h2>

        {/* Tabs */}
        <div className="flex border-b border-[#333] mb-6">
          <button
            className={`px-4 py-2 text-sm font-medium ${
              activeTab === "how-it-works"
                ? "text-white border-b-2 border-[#e50914]"
                : "text-[#b3b3b3] hover:text-white"
            }`}
            onClick={() => setActiveTab("how-it-works")}
          >
            How It Works
          </button>
          <button
            className={`px-4 py-2 text-sm font-medium ${
              activeTab === "rewards" ? "text-white border-b-2 border-[#e50914]" : "text-[#b3b3b3] hover:text-white"
            }`}
            onClick={() => setActiveTab("rewards")}
          >
            10-Level Rewards
          </button>
          <button
            className={`px-4 py-2 text-sm font-medium ${
              activeTab === "share" ? "text-white border-b-2 border-[#e50914]" : "text-[#b3b3b3] hover:text-white"
            }`}
            onClick={() => setActiveTab("share")}
          >
            Share Now
          </button>
        </div>

        {/* How It Works Tab */}
        {activeTab === "how-it-works" && (
          <div className="space-y-6">
            <div className="bg-[#232323] rounded-lg p-4">
              <h3 className="font-bold text-lg mb-2">Share Your Unique Link</h3>
              <p className="text-[#b3b3b3] mb-3">
                Share your personal referral link with friends, family, and followers on social media. When they join
                MOKEN using your link, you'll both earn rewards!
              </p>

              <div className="flex items-center justify-between mb-2">
                <div className="text-sm truncate flex-1 bg-[#181818] rounded p-2 mr-2 overflow-hidden">
                  {referralLink}
                </div>
                <button
                  onClick={copyReferralLink}
                  className="flex items-center gap-1 bg-[#333] hover:bg-[#444] transition-colors p-2 rounded"
                >
                  {copied ? <Check size={18} className="text-green-500" /> : <Copy size={18} />}
                  <span>{copied ? "Copied!" : "Copy"}</span>
                </button>
              </div>
            </div>

            <div className="bg-[#232323] rounded-lg p-4">
              <h3 className="font-bold text-lg mb-2">Build Your Network</h3>
              <p className="text-[#b3b3b3] mb-3">
                As your network grows, you'll earn rewards from up to 10 levels deep in your referral tree. The more
                people join through your network, the more MKO tokens you earn!
              </p>

              <div className="relative">
                <div className="h-[200px] w-full relative">
                  <Image
                    src="/placeholder.svg?height=200&width=400&text=Network+Diagram"
                    alt="Network diagram"
                    fill
                    className="object-contain"
                  />
                </div>
              </div>
            </div>

            <div className="bg-[#232323] rounded-lg p-4">
              <h3 className="font-bold text-lg mb-2">Earn MKO Tokens</h3>
              <p className="text-[#b3b3b3] mb-3">
                Each time someone in your referral network subscribes or makes a purchase, you earn a percentage of the
                transaction value in MKO tokens based on their level in your network.
              </p>

              <div className="flex items-center justify-center gap-2 bg-[#181818] rounded-lg p-3">
                <div className="w-10 h-10 relative">
                  <Image
                    src="/placeholder.svg?height=40&width=40&text=MKO"
                    alt="MKO token"
                    width={40}
                    height={40}
                    className="rounded-full"
                  />
                </div>
                <div>
                  <p className="font-medium">MKO Tokens can be used for:</p>
                  <ul className="text-sm text-[#b3b3b3] list-disc ml-5">
                    <li>Premium movie subscriptions</li>
                    <li>Exclusive content access</li>
                    <li>Trade on supported exchanges</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Rewards Tab */}
        {activeTab === "rewards" && (
          <div className="space-y-4">
            <div className="bg-[#232323] rounded-lg p-4 mb-4">
              <h3 className="font-bold text-lg mb-2">10-Level Unilevel Rewards System</h3>
              <p className="text-[#b3b3b3] mb-3">
                Our unique 10-level reward structure lets you earn MKO tokens from your entire network, not just direct
                referrals. Here's how much you earn from each level:
              </p>
            </div>

            <div className="grid gap-2">
              {levelRewards.map((reward) => (
                <div
                  key={reward.level}
                  className={`flex items-center justify-between p-3 rounded-lg ${
                    reward.level === 1
                      ? "bg-gradient-to-r from-[#e50914] to-[#ff3b30]"
                      : reward.level <= 3
                        ? "bg-gradient-to-r from-[#333] to-[#444]"
                        : "bg-[#232323]"
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div
                      className={`
                      w-10 h-10 rounded-full flex items-center justify-center font-bold
                      ${reward.level === 1 ? "bg-white text-[#e50914]" : "bg-[#181818] text-white"}
                    `}
                    >
                      {reward.level}
                    </div>
                    <div>
                      <p className="font-medium">Level {reward.level}</p>
                      <p className="text-xs text-[#b3b3b3]">{reward.description}</p>
                    </div>
                  </div>
                  <div className="text-xl font-bold">{reward.percentage}</div>
                </div>
              ))}
            </div>

            <div className="bg-[#232323] rounded-lg p-4 mt-4">
              <h3 className="font-bold text-lg mb-2">Example Earnings</h3>
              <p className="text-[#b3b3b3] mb-3">
                If a Level 1 referral subscribes for 100 MKO, you earn 10 MKO tokens. If their referral (your Level 2)
                subscribes, you earn 7 MKO tokens, and so on.
              </p>
              <div className="bg-[#181818] rounded-lg p-3">
                <p className="text-center font-medium">The earning potential is unlimited!</p>
              </div>
            </div>
          </div>
        )}

        {/* Share Tab */}
        {activeTab === "share" && (
          <div className="space-y-6">
            <div className="bg-[#232323] rounded-lg p-4">
              <h3 className="font-bold text-lg mb-2">Share Your Referral Link</h3>
              <p className="text-[#b3b3b3] mb-3">
                Choose how you want to share your unique referral link. The more people join, the more rewards you earn!
              </p>

              <div className="flex items-center justify-between mb-4">
                <div className="text-sm truncate flex-1 bg-[#181818] rounded p-2 mr-2 overflow-hidden">
                  {referralLink}
                </div>
                <button
                  onClick={copyReferralLink}
                  className="flex items-center gap-1 bg-[#333] hover:bg-[#444] transition-colors p-2 rounded"
                >
                  {copied ? <Check size={18} className="text-green-500" /> : <Copy size={18} />}
                  <span>{copied ? "Copied!" : "Copy"}</span>
                </button>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <button className="bg-[#1DA1F2] hover:bg-[#1a94e2] transition-colors rounded-lg py-3 px-4 flex items-center justify-center gap-2">
                  <Twitter size={20} />
                  <span>Share on Twitter</span>
                </button>
                <button className="bg-[#4267B2] hover:bg-[#3b5da0] transition-colors rounded-lg py-3 px-4 flex items-center justify-center gap-2">
                  <Facebook size={20} />
                  <span>Share on Facebook</span>
                </button>
                <button className="bg-[#555] hover:bg-[#444] transition-colors rounded-lg py-3 px-4 flex items-center justify-center gap-2">
                  <Mail size={20} />
                  <span>Share via Email</span>
                </button>
                <button className="bg-[#555] hover:bg-[#444] transition-colors rounded-lg py-3 px-4 flex items-center justify-center gap-2">
                  <LinkIcon size={20} />
                  <span>More Options</span>
                </button>
              </div>
            </div>

            <div className="bg-[#232323] rounded-lg p-4">
              <h3 className="font-bold text-lg mb-2">Share Your Success Story</h3>
              <p className="text-[#b3b3b3] mb-3">
                Maximize your referrals by sharing how much you've earned! Include your link in:
              </p>

              <ul className="space-y-2 mb-4">
                <li className="flex items-center gap-2">
                  <div className="bg-[#e50914] rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold">
                    ✓
                  </div>
                  <span>Social media posts and profiles</span>
                </li>
                <li className="flex items-center gap-2">
                  <div className="bg-[#e50914] rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold">
                    ✓
                  </div>
                  <span>YouTube video descriptions</span>
                </li>
                <li className="flex items-center gap-2">
                  <div className="bg-[#e50914] rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold">
                    ✓
                  </div>
                  <span>Forum signatures and blog posts</span>
                </li>
                <li className="flex items-center gap-2">
                  <div className="bg-[#e50914] rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold">
                    ✓
                  </div>
                  <span>Direct messages to friends and colleagues</span>
                </li>
              </ul>

              <div className="bg-[#181818] rounded-lg p-3 text-center">
                <p className="italic text-sm">
                  "I've earned over 1,000 MKO tokens just by sharing my referral link with my network! Join MOKEN and
                  start earning too."
                </p>
              </div>
            </div>
          </div>
        )}

        <div className="mt-6 flex justify-end">
          <button
            onClick={onClose}
            className="bg-[#e50914] hover:bg-[#f40612] transition-colors py-2 px-4 rounded font-medium"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  )
}

