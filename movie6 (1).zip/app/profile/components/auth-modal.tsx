"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import { X, AlertTriangle } from "lucide-react"
import { useAuthState } from "@/hooks/use-auth"
import { useSearchParams } from "next/navigation"

interface AuthModalProps {
  onClose: () => void
}

export function AuthModal({ onClose }: AuthModalProps) {
  const { login } = useAuthState()
  const [step, setStep] = useState<"select-wallet" | "connecting" | "success">("select-wallet")
  const [selectedWallet, setSelectedWallet] = useState<"ethereum" | "solana" | null>(null)
  const [error, setError] = useState<string | null>(null)
  const searchParams = useSearchParams()
  const [referrerId, setReferrerId] = useState<string | null>(null)

  // Check for referral code in URL
  useEffect(() => {
    const ref = searchParams?.get("ref")
    if (ref) {
      setReferrerId(ref)
      // Store the referrer ID in localStorage temporarily
      localStorage.setItem("pending-referrer", ref)
    } else {
      // Check if there's a stored referrer ID from previous visits
      const storedRef = localStorage.getItem("pending-referrer")
      if (storedRef) {
        setReferrerId(storedRef)
      }
    }
  }, [searchParams])

  // Update the handleConnectWallet functions to pass the referrer ID
  const handleConnectMetaMask = async () => {
    setSelectedWallet("ethereum")
    setStep("connecting")
    setError(null)

    try {
      // Check if MetaMask is installed
      if (typeof window.ethereum === "undefined") {
        throw new Error("MetaMask is not installed! Please install MetaMask to continue.")
      }

      try {
        // Request account access
        const accounts = await window.ethereum.request({ method: "eth_requestAccounts" })

        if (accounts.length === 0) {
          throw new Error("No Ethereum accounts found. Please create an account in MetaMask.")
        }

        // Simulate checking for MKO token
        await new Promise((resolve) => setTimeout(resolve, 1000))

        // Login with the first account
        await login(accounts[0], "ethereum")
        setStep("success")

        // Close modal after success
        setTimeout(() => {
          onClose()
        }, 2000)
      } catch (err: any) {
        console.error("MetaMask connection error:", err)
        if (err.code === 4001) {
          setError("You rejected the connection request. Please try again.")
        } else {
          setError(err.message || "Failed to connect to MetaMask. Please try again.")
        }
        setStep("select-wallet")
      }
    } catch (err: any) {
      console.error("MetaMask error:", err)
      setError(err.message || "An error occurred while connecting to MetaMask")
      setStep("select-wallet")
    }
  }

  const handleConnectPhantom = async () => {
    setSelectedWallet("solana")
    setStep("connecting")
    setError(null)

    try {
      // Check if Phantom is installed
      if (!window.solana || !window.solana.isPhantom) {
        throw new Error("Phantom wallet is not installed! Please install Phantom to continue.")
      }

      try {
        // Connect to Phantom
        const { publicKey } = await window.solana.connect()

        if (!publicKey) {
          throw new Error("No Solana accounts found. Please create an account in Phantom.")
        }

        // Simulate checking for MKO token
        await new Promise((resolve) => setTimeout(resolve, 1000))

        // Login with the public key
        await login(publicKey.toString(), "solana")
        setStep("success")

        // Close modal after success
        setTimeout(() => {
          onClose()
        }, 2000)
      } catch (err: any) {
        console.error("Phantom connection error:", err)
        setError(err.message || "Failed to connect to Phantom. Please try again.")
        setStep("select-wallet")
      }
    } catch (err: any) {
      console.error("Phantom error:", err)
      setError(err.message || "An error occurred while connecting to Phantom")
      setStep("select-wallet")
    }
  }

  // Simulate wallet connection for demo purposes
  const handleSimulateWallet = async (type: "ethereum" | "solana") => {
    setSelectedWallet(type)
    setStep("connecting")
    setError(null)

    // Simulate connection delay
    await new Promise((resolve) => setTimeout(resolve, 1500))

    // Generate a random wallet address
    const randomAddress =
      type === "ethereum"
        ? `0x${Array.from({ length: 40 }, () => Math.floor(Math.random() * 16).toString(16)).join("")}`
        : `${Array.from({ length: 44 }, () => Math.floor(Math.random() * 16).toString(16)).join("")}`

    // Login with the random address and referrer ID if available
    await login(randomAddress, type, referrerId || undefined)

    // Clear the pending referrer from localStorage after successful signup
    localStorage.removeItem("pending-referrer")

    setStep("success")

    // Close modal after success
    setTimeout(() => {
      onClose()
    }, 2000)
  }

  // Add a section to show referral info if available
  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
      <div className="bg-[#181818] rounded-lg max-w-md w-full p-6 relative">
        <button onClick={onClose} className="absolute top-4 right-4 text-[#b3b3b3] hover:text-white">
          <X size={24} />
        </button>

        {step === "select-wallet" && (
          <>
            <h2 className="text-2xl font-bold mb-6 text-center">Connect Your Wallet</h2>

            {referrerId && (
              <div className="mb-6 p-3 bg-[#232323] border border-[#e50914]/30 rounded-lg">
                <p className="text-center text-sm">
                  You were invited by a friend! Connect your wallet to join their network and earn rewards together.
                </p>
              </div>
            )}

            {error && (
              <div className="mb-6 p-3 bg-red-900/50 border border-red-700 rounded-lg flex items-center gap-2 text-sm">
                <AlertTriangle size={18} className="text-red-500" />
                <p>{error}</p>
              </div>
            )}

            <p className="text-[#b3b3b3] mb-6 text-center">
              Connect your wallet to access premium features. You need MKO tokens to watch full movies.
            </p>

            <div className="space-y-4">
              <button
                onClick={() => handleSimulateWallet("ethereum")}
                className="w-full bg-[#232323] hover:bg-[#333] transition-colors p-4 rounded-lg flex items-center gap-4"
              >
                <Image
                  src="/placeholder.svg?height=40&width=40&text=MM"
                  width={40}
                  height={40}
                  alt="MetaMask"
                  className="rounded-full"
                />
                <div className="text-left">
                  <p className="font-semibold">MetaMask</p>
                  <p className="text-xs text-[#b3b3b3]">Connect to your MetaMask wallet</p>
                </div>
              </button>

              <button
                onClick={() => handleSimulateWallet("solana")}
                className="w-full bg-[#232323] hover:bg-[#333] transition-colors p-4 rounded-lg flex items-center gap-4"
              >
                <Image
                  src="/placeholder.svg?height=40&width=40&text=Ph"
                  width={40}
                  height={40}
                  alt="Phantom"
                  className="rounded-full"
                />
                <div className="text-left">
                  <p className="font-semibold">Phantom</p>
                  <p className="text-xs text-[#b3b3b3]">Connect to your Phantom wallet (Solana)</p>
                </div>
              </button>

              <div className="border-t border-[#333] pt-4">
                <p className="text-center text-sm text-[#b3b3b3] mb-4">Don't have MKO tokens yet?</p>
                <button className="w-full bg-[#e50914] text-white font-bold py-3 rounded-lg hover:bg-[#f40612] transition-colors">
                  Learn How to Get MKO Tokens
                </button>
              </div>
            </div>
          </>
        )}

        {step === "connecting" && (
          <div className="text-center py-6">
            <div className="w-20 h-20 border-4 border-[#e50914] border-t-transparent rounded-full animate-spin mx-auto mb-6"></div>
            <h2 className="text-xl font-bold mb-2">Connecting to Wallet</h2>
            <p className="text-[#b3b3b3]">
              {selectedWallet === "ethereum"
                ? "Please confirm the connection in MetaMask..."
                : "Please confirm the connection in Phantom..."}
            </p>
          </div>
        )}

        {step === "success" && (
          <div className="text-center py-6">
            <div className="w-20 h-20 bg-[#e50914] rounded-full mx-auto mb-6 flex items-center justify-center">
              <svg width="40" height="40" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M5 13l4 4L19 7" stroke="white" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </div>
            <h2 className="text-xl font-bold mb-2">Connected Successfully!</h2>
            <p className="text-[#b3b3b3]">
              Your {selectedWallet === "ethereum" ? "MetaMask" : "Phantom"} wallet has been connected. You now have
              access to premium content.
            </p>
          </div>
        )}
      </div>
    </div>
  )
}

