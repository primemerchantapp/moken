"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import { useAuthState } from "@/hooks/use-auth"
import { AuthModal } from "./auth-modal"
import { LogOut, Settings, Clock, BookmarkCheck, Heart, Wallet, Share2, Users, Award, Copy, Check } from "lucide-react"
import { ReferralRewardsModal } from "./referral-rewards-modal"

export function ProfileContent() {
  const { user, logout, checkTokenBalance } = useAuthState()
  const [activeTab, setActiveTab] = useState("overview")
  const [showAuthModal, setShowAuthModal] = useState(false)
  const [mkoBalance, setMkoBalance] = useState<number | null>(null)
  const [username, setUsername] = useState("")
  const [showReferralModal, setShowReferralModal] = useState(false)
  const [copied, setCopied] = useState(false)
  const [referralStats, setReferralStats] = useState({
    directReferrals: 0,
    totalReferrals: 0,
    totalEarned: 0,
  })

  useEffect(() => {
    if (user) {
      setUsername(user.username || "")
      // In a real app, we would fetch the referral stats from the backend
      setReferralStats({
        directReferrals: Math.floor(Math.random() * 10),
        totalReferrals: Math.floor(Math.random() * 50),
        totalEarned: Math.floor(Math.random() * 1000),
      })
    }
  }, [user])

  const generateReferralLink = () => {
    if (!user) return ""
    const baseUrl = typeof window !== "undefined" ? window.location.origin : "https://moken-movie.vercel.app"
    return `${baseUrl}/register?ref=${user.id}`
  }

  const copyReferralLink = () => {
    const link = generateReferralLink()
    navigator.clipboard.writeText(link)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  // Update the rest of the component...

  // Inside the return, after the wallet div and before the sidebar navigation buttons, add the Referral section:
  if (!user) {
    return (
      <div className="text-center py-20">
        <h1 className="text-2xl font-bold mb-4">Please Sign In to View Your Profile</h1>
        <p className="text-[#b3b3b3] mb-6">Connect your wallet to access premium features and exclusive content.</p>
        <button
          className="bg-[#e50914] text-white px-6 py-3 rounded font-bold hover:bg-[#f40612] transition-colors"
          onClick={() => setShowAuthModal(true)}
        >
          Sign In
        </button>

        {showAuthModal && <AuthModal onClose={() => setShowAuthModal(false)} />}
      </div>
    )
  }

  const handleCheckBalance = async () => {
    const balance = await checkTokenBalance()
    setMkoBalance(balance)
  }

  // Format wallet address for display
  const formatWalletAddress = (address: string) => {
    return `${address.slice(0, 6)}...${address.slice(-4)}`
  }

  return (
    <div className="flex flex-col lg:flex-row gap-8">
      {/* Profile Sidebar */}
      <div className="lg:w-1/3">
        <div className="bg-[#181818] rounded-lg p-6 shadow-lg">
          <div className="flex flex-col items-center mb-6">
            <div className="relative w-32 h-32 mb-4">
              <Image
                src={user.avatar || "/placeholder.svg?height=128&width=128"}
                alt="Profile picture"
                fill
                className="rounded-full object-cover border-2 border-[#e50914]"
              />
            </div>
            <h1 className="text-2xl font-bold">{user.username}</h1>
            <p className="text-[#b3b3b3]">Member since {user.joinedDate.toLocaleDateString()}</p>
          </div>

          <div className="space-y-4">
            <div className="bg-[#232323] rounded-lg p-4">
              <div className="flex justify-between items-center mb-2">
                <div className="flex items-center gap-2">
                  <Wallet size={20} className="text-[#e50914]" />
                  <span className="font-medium">Wallet</span>
                </div>
                <button onClick={handleCheckBalance} className="text-xs text-[#b3b3b3] hover:text-white">
                  Check Balance
                </button>
              </div>
              <p className="text-sm">{formatWalletAddress(user.walletAddress)}</p>
              <p className="text-sm text-[#b3b3b3]">
                {user.walletType === "ethereum" ? "Ethereum (MetaMask)" : "Solana (Phantom)"}
              </p>

              {mkoBalance !== null && (
                <div className="mt-2 flex items-center gap-2 text-[#e5b80b]">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="12" cy="12" r="10" fill="#e5b80b" />
                    <text x="12" y="16" textAnchor="middle" fill="black" fontSize="12" fontWeight="bold">
                      M
                    </text>
                  </svg>
                  <span>{mkoBalance} MKO Tokens</span>
                </div>
              )}
            </div>

            {/* Share and Earn Rewards Section */}
            <div className="bg-gradient-to-r from-[#232323] to-[#333] rounded-lg p-4">
              <div className="flex justify-between items-center mb-2">
                <div className="flex items-center gap-2">
                  <Share2 size={20} className="text-[#e50914]" />
                  <span className="font-medium">Share & Earn</span>
                </div>
                <button
                  onClick={() => setShowReferralModal(true)}
                  className="text-xs bg-[#e50914] text-white px-2 py-1 rounded hover:bg-[#f40612] transition-colors"
                >
                  View Rewards
                </button>
              </div>

              <div className="flex items-center justify-between mb-2">
                <p className="text-sm">Your Referral Link:</p>
                <button
                  onClick={copyReferralLink}
                  className="flex items-center gap-1 text-xs bg-[#333] hover:bg-[#444] transition-colors p-1 rounded"
                >
                  {copied ? <Check size={14} className="text-green-500" /> : <Copy size={14} />}
                  <span>{copied ? "Copied!" : "Copy"}</span>
                </button>
              </div>

              <div className="bg-[#181818] rounded p-2 mb-3 text-xs truncate">{generateReferralLink()}</div>

              <div className="grid grid-cols-3 gap-1 text-center">
                <div className="bg-[#181818] rounded p-2">
                  <p className="text-sm font-bold">{referralStats.directReferrals}</p>
                  <p className="text-xs text-[#b3b3b3]">Direct Refs</p>
                </div>
                <div className="bg-[#181818] rounded p-2">
                  <p className="text-sm font-bold">{referralStats.totalReferrals}</p>
                  <p className="text-xs text-[#b3b3b3]">Total Team</p>
                </div>
                <div className="bg-[#181818] rounded p-2">
                  <p className="text-sm font-bold text-[#e5b80b]">{referralStats.totalEarned}</p>
                  <p className="text-xs text-[#b3b3b3]">MKO Earned</p>
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <button
                className={`w-full text-left px-4 py-3 rounded-lg flex items-center gap-3 ${activeTab === "overview" ? "bg-[#232323]" : "hover:bg-[#232323] transition-colors"}`}
                onClick={() => setActiveTab("overview")}
              >
                <BookmarkCheck size={20} />
                <span>Overview</span>
              </button>

              <button
                className={`w-full text-left px-4 py-3 rounded-lg flex items-center gap-3 ${activeTab === "watchlist" ? "bg-[#232323]" : "hover:bg-[#232323] transition-colors"}`}
                onClick={() => setActiveTab("watchlist")}
              >
                <Heart size={20} />
                <span>Watchlist</span>
              </button>

              <button
                className={`w-full text-left px-4 py-3 rounded-lg flex items-center gap-3 ${activeTab === "history" ? "bg-[#232323]" : "hover:bg-[#232323] transition-colors"}`}
                onClick={() => setActiveTab("history")}
              >
                <Clock size={20} />
                <span>Watch History</span>
              </button>

              <button
                className={`w-full text-left px-4 py-3 rounded-lg flex items-center gap-3 ${activeTab === "referrals" ? "bg-[#232323]" : "hover:bg-[#232323] transition-colors"}`}
                onClick={() => setActiveTab("referrals")}
              >
                <Users size={20} />
                <span>Referrals</span>
              </button>

              <button
                className={`w-full text-left px-4 py-3 rounded-lg flex items-center gap-3 ${activeTab === "settings" ? "bg-[#232323]" : "hover:bg-[#232323] transition-colors"}`}
                onClick={() => setActiveTab("settings")}
              >
                <Settings size={20} />
                <span>Settings</span>
              </button>

              <button
                className="w-full text-left px-4 py-3 rounded-lg flex items-center gap-3 text-[#b3b3b3] hover:bg-[#232323] hover:text-white transition-colors"
                onClick={logout}
              >
                <LogOut size={20} />
                <span>Sign Out</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="lg:w-2/3">
        {activeTab === "overview" && (
          <div className="space-y-6">
            <div className="bg-[#181818] rounded-lg p-6 shadow-lg">
              <h2 className="text-xl font-bold mb-4">Subscription Status</h2>
              <div className="flex items-center gap-4 p-4 bg-gradient-to-r from-[#1a1a1a] to-[#232323] rounded-lg">
                <div className="w-16 h-16 bg-[#e50914] rounded-full flex items-center justify-center">
                  <svg width="32" height="32" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path
                      d="M5 13l4 4L19 7"
                      stroke="white"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                </div>
                <div>
                  <h3 className="font-bold">Premium Account</h3>
                  <p className="text-[#b3b3b3]">You have access to all premium content and features.</p>
                </div>
              </div>
            </div>

            <div className="bg-[#181818] rounded-lg p-6 shadow-lg">
              <h2 className="text-xl font-bold mb-4">Continue Watching</h2>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {/* These would be dynamic in a real app */}
                <div className="relative aspect-video rounded-lg overflow-hidden">
                  <Image
                    src="/placeholder.svg?height=180&width=320&text=Movie"
                    alt="Continue watching"
                    fill
                    className="object-cover"
                  />
                  <div className="absolute bottom-0 left-0 right-0 p-2 bg-gradient-to-t from-black/80 to-transparent">
                    <p className="text-sm font-medium">The Dark Knight</p>
                    <div className="w-full h-1 bg-white/30 mt-1">
                      <div className="h-full bg-[#e50914]" style={{ width: "45%" }}></div>
                    </div>
                  </div>
                </div>

                <div className="relative aspect-video rounded-lg overflow-hidden">
                  <Image
                    src="/placeholder.svg?height=180&width=320&text=Series"
                    alt="Continue watching"
                    fill
                    className="object-cover"
                  />
                  <div className="absolute bottom-0 left-0 right-0 p-2 bg-gradient-to-t from-black/80 to-transparent">
                    <p className="text-sm font-medium">Stranger Things</p>
                    <div className="w-full h-1 bg-white/30 mt-1">
                      <div className="h-full bg-[#e50914]" style={{ width: "75%" }}></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-[#181818] rounded-lg p-6 shadow-lg">
              <h2 className="text-xl font-bold mb-4">Recommended For You</h2>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {[1, 2, 3, 4].map((i) => (
                  <div key={i} className="relative aspect-[2/3] rounded-lg overflow-hidden">
                    <Image
                      src={`/placeholder.svg?height=300&width=200&text=Movie+${i}`}
                      alt="Recommended movie"
                      fill
                      className="object-cover"
                    />
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === "referrals" && (
          <div className="bg-[#181818] rounded-lg p-6 shadow-lg">
            <h2 className="text-xl font-bold mb-4">Your Referral Network</h2>

            <div className="bg-gradient-to-r from-[#232323] to-[#333] rounded-lg p-4 mb-6">
              <div className="flex flex-col md:flex-row items-center justify-between gap-4 mb-4">
                <div>
                  <h3 className="font-bold flex items-center gap-2">
                    <Award size={20} className="text-[#e5b80b]" />
                    10-Level Unilevel Rewards System
                  </h3>
                  <p className="text-sm text-[#b3b3b3]">Earn tokens when users join through your referral link</p>
                </div>

                <div className="flex gap-2">
                  <button
                    onClick={copyReferralLink}
                    className="flex items-center gap-2 bg-[#333] hover:bg-[#444] transition-colors py-2 px-3 rounded"
                  >
                    {copied ? <Check size={16} className="text-green-500" /> : <Copy size={16} />}
                    <span>{copied ? "Copied!" : "Copy Link"}</span>
                  </button>

                  <button
                    className="flex items-center gap-2 bg-[#e50914] hover:bg-[#f40612] transition-colors py-2 px-3 rounded"
                    onClick={() => setShowReferralModal(true)}
                  >
                    <Share2 size={16} />
                    <span>Share</span>
                  </button>
                </div>
              </div>

              <div className="bg-[#181818] rounded p-2 mb-4 text-sm truncate">{generateReferralLink()}</div>

              <div className="grid grid-cols-3 gap-4 mb-4">
                <div className="bg-[#181818] rounded p-3 text-center">
                  <p className="text-2xl font-bold">{referralStats.directReferrals}</p>
                  <p className="text-xs text-[#b3b3b3]">Direct Referrals</p>
                </div>
                <div className="bg-[#181818] rounded p-3 text-center">
                  <p className="text-2xl font-bold">{referralStats.totalReferrals}</p>
                  <p className="text-xs text-[#b3b3b3]">Total Network Size</p>
                </div>
                <div className="bg-[#181818] rounded p-3 text-center">
                  <p className="text-2xl font-bold text-[#e5b80b]">{referralStats.totalEarned}</p>
                  <p className="text-xs text-[#b3b3b3]">MKO Tokens Earned</p>
                </div>
              </div>
            </div>

            <h3 className="text-lg font-bold mb-3">Your Referral Team</h3>

            <div className="overflow-x-auto">
              <table className="w-full border-collapse">
                <thead>
                  <tr className="bg-[#232323]">
                    <th className="p-2 text-left">Username</th>
                    <th className="p-2 text-left">Level</th>
                    <th className="p-2 text-left">Joined</th>
                    <th className="p-2 text-left">Rewards</th>
                  </tr>
                </thead>
                <tbody>
                  {/* These would be dynamic in a real app */}
                  <tr className="border-b border-[#333]">
                    <td className="p-2">Crypto_Enthusiast</td>
                    <td className="p-2">Level 1</td>
                    <td className="p-2">Mar 10, 2025</td>
                    <td className="p-2 text-[#e5b80b]">50 MKO</td>
                  </tr>
                  <tr className="border-b border-[#333]">
                    <td className="p-2">MovieBuff42</td>
                    <td className="p-2">Level 1</td>
                    <td className="p-2">Mar 5, 2025</td>
                    <td className="p-2 text-[#e5b80b]">50 MKO</td>
                  </tr>
                  <tr className="border-b border-[#333]">
                    <td className="p-2">Blockchain_Fan</td>
                    <td className="p-2">Level 2</td>
                    <td className="p-2">Mar 2, 2025</td>
                    <td className="p-2 text-[#e5b80b]">25 MKO</td>
                  </tr>
                  <tr className="border-b border-[#333]">
                    <td className="p-2">Cinema_Lover</td>
                    <td className="p-2">Level 3</td>
                    <td className="p-2">Feb 28, 2025</td>
                    <td className="p-2 text-[#e5b80b]">10 MKO</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === "watchlist" && (
          <div className="bg-[#181818] rounded-lg p-6 shadow-lg">
            <h2 className="text-xl font-bold mb-4">Your Watchlist</h2>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <div key={i} className="relative aspect-[2/3] rounded-lg overflow-hidden">
                  <Image
                    src={`/placeholder.svg?height=300&width=200&text=Watchlist+${i}`}
                    alt="Watchlist item"
                    fill
                    className="object-cover"
                  />
                  <div className="absolute bottom-0 left-0 right-0 p-2 bg-gradient-to-t from-black/80 to-transparent">
                    <p className="text-sm font-medium">Movie Title {i}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === "history" && (
          <div className="bg-[#181818] rounded-lg p-6 shadow-lg">
            <h2 className="text-xl font-bold mb-4">Watch History</h2>
            <div className="space-y-4">
              {[1, 2, 3, 4, 5].map((i) => (
                <div key={i} className="flex gap-4 p-3 hover:bg-[#232323] rounded-lg transition-colors">
                  <div className="relative w-20 h-12 rounded-lg overflow-hidden flex-shrink-0">
                    <Image
                      src={`/placeholder.svg?height=48&width=80&text=${i}`}
                      alt="History item"
                      fill
                      className="object-cover"
                    />
                  </div>
                  <div>
                    <p className="font-medium">Movie Title {i}</p>
                    <p className="text-sm text-[#b3b3b3]">
                      Watched on {new Date(Date.now() - i * 86400000).toLocaleDateString()}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === "settings" && (
          <div className="bg-[#181818] rounded-lg p-6 shadow-lg">
            <h2 className="text-xl font-bold mb-4">Account Settings</h2>
            <div className="space-y-6">
              <div>
                <label className="block text-[#b3b3b3] mb-1">Username</label>
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full bg-[#232323] border border-[#333] rounded-lg px-4 py-2 focus:outline-none focus:border-[#e50914]"
                />
              </div>

              <div>
                <label className="block text-[#b3b3b3] mb-1">Email Notifications</label>
                <div className="space-y-2">
                  <div className="flex items-center">
                    <input type="checkbox" id="notify-new" className="mr-2" defaultChecked />
                    <label htmlFor="notify-new">New releases</label>
                  </div>
                  <div className="flex items-center">
                    <input type="checkbox" id="notify-recommendations" className="mr-2" defaultChecked />
                    <label htmlFor="notify-recommendations">Recommendations</label>
                  </div>
                  <div className="flex items-center">
                    <input type="checkbox" id="notify-account" className="mr-2" defaultChecked />
                    <label htmlFor="notify-account">Account updates</label>
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-[#b3b3b3] mb-1">Playback Settings</label>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <label htmlFor="autoplay">Autoplay next episode</label>
                    <input type="checkbox" id="autoplay" defaultChecked />
                  </div>
                  <div className="flex items-center justify-between">
                    <label htmlFor="autopreviews">Autoplay previews</label>
                    <input type="checkbox" id="autopreviews" defaultChecked />
                  </div>
                </div>
              </div>

              <button className="w-full bg-[#e50914] text-white font-bold py-2 rounded-lg hover:bg-[#f40612] transition-colors">
                Save Settings
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Referral Rewards Modal */}
      {showReferralModal && (
        <ReferralRewardsModal onClose={() => setShowReferralModal(false)} referralLink={generateReferralLink()} />
      )}
    </div>
  )
}

