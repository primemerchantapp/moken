"use client"

import { useState, useEffect } from "react"
import { Header } from "../components/header"
import { BottomNav } from "../components/bottom-nav"
import { SplashScreen } from "../components/splash-screen"
import { ProfileContent } from "./components/profile-content"
import { AuthModal } from "./components/auth-modal"
import { useAuthState } from "@/hooks/use-auth"
import { useSearchParams } from "next/navigation"

export default function ProfilePage() {
  const [searchResults, setSearchResults] = useState([])
  const [showSearchResults, setShowSearchResults] = useState(false)
  const [showAuthModal, setShowAuthModal] = useState(false)
  const { user, isAuthenticated, loading } = useAuthState()
  const searchParams = useSearchParams()

  useEffect(() => {
    // Set document title
    document.title = "Profile - MOKEN"

    // Check for referral code in URL
    const ref = searchParams?.get("ref")
    if (ref) {
      // If there's a referral code and user is not authenticated, show auth modal
      if (!isAuthenticated && !loading) {
        setShowAuthModal(true)
      }
    } else if (!isAuthenticated && !loading) {
      // If not authenticated and not loading, show auth modal
      setShowAuthModal(true)
    }
  }, [isAuthenticated, loading, searchParams])

  const handleSearch = (query: string) => {
    if (!query.trim()) {
      setShowSearchResults(false)
      return
    }

    // Mock search results
    setSearchResults([])
    setShowSearchResults(true)
  }

  if (loading) {
    return <SplashScreen />
  }

  return (
    <div className="min-h-screen bg-[#141414] text-white">
      {/* Header */}
      <Header onSearch={handleSearch} searchResults={searchResults} showSearchResults={showSearchResults} />

      <main className="pt-16 pb-20">
        <div className="max-w-7xl mx-auto px-4 py-8 md:px-8 lg:px-14">
          <ProfileContent />
        </div>
      </main>

      {/* Authentication Modal */}
      {showAuthModal && <AuthModal onClose={() => setShowAuthModal(false)} />}

      {/* Bottom Navigation */}
      <BottomNav />
    </div>
  )
}

