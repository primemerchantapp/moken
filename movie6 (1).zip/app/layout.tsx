import type React from "react"
import "./globals.css"
import type { Metadata } from "next"
import { AuthProvider } from "@/hooks/use-auth"

// Update the metadata title
export const metadata: Metadata = {
  title: "MOKEN - Movie Streaming",
  description: "MOKEN is a Movie and Music Streaming Hub.",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />
        <link
          href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700;900&display=swap"
          rel="stylesheet"
        />
      </head>
      <body>
        <AuthProvider>{children}</AuthProvider>
      </body>
    </html>
  )
}



import './globals.css'