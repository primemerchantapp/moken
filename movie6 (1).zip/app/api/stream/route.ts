import { NextResponse } from "next/server"
import tmdbScrape from "@/lib/vidsrc-scraper"

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const tmdbId = searchParams.get("tmdbId")
  const type = searchParams.get("type") as "movie" | "tv"
  const season = searchParams.get("season") ? Number.parseInt(searchParams.get("season")!) : undefined
  const episode = searchParams.get("episode") ? Number.parseInt(searchParams.get("episode")!) : undefined

  if (!tmdbId || !type) {
    return NextResponse.json({ error: "Missing required parameters" }, { status: 400 })
  }

  try {
    const sources = await tmdbScrape(tmdbId, type, season, episode)
    return NextResponse.json({ sources })
  } catch (error) {
    console.error("Error fetching stream sources:", error)
    return NextResponse.json({ error: "Failed to fetch stream sources" }, { status: 500 })
  }
}

