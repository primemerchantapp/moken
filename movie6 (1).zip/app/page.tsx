"use client"

import { useEffect, useState } from "react"
import Link from "next/link"

// Import the BannerSlider component
import { BannerSlider } from "./components/banner-slider"
// Import the Header component
import { Header } from "./components/header"
// Import the BottomNav component
import { BottomNav } from "./components/bottom-nav"
// Import the SplashScreen component
import { SplashScreen } from "./components/splash-screen"
// Import the MovieCard component at the top of the file
import { MovieCard } from "./components/movie-card"
// Import the SeriesSection component at the top of the file
import { SeriesSection } from "./components/series-section"

// API configuration
const API_KEY = "7a5cf3c679b58ed507187030e928245a"
const IMAGE_BASE_URL = "https://image.tmdb.org/t/p/"

interface Movie {
  id: number
  title: string
  poster_path: string
  backdrop_path: string
  vote_average: number
  release_date: string
  genre_ids: number[]
  overview: string
}

interface Genre {
  id: number
  name: string
}

export default function HomePage() {
  const [popularMovies, setPopularMovies] = useState<Movie[]>([])
  const [upcomingMovies, setUpcomingMovies] = useState<Movie[]>([])
  const [trendingMovies, setTrendingMovies] = useState<Movie[]>([])
  const [topRatedMovies, setTopRatedMovies] = useState<Movie[]>([])
  const [genres, setGenres] = useState<{ [key: number]: string }>({})
  const [activeSlide, setActiveSlide] = useState(0)
  // and move the search state and functions to the main component
  const [searchQuery, setSearchQuery] = useState("")
  const [searchResults, setSearchResults] = useState<Movie[]>([])
  const [isSearching, setIsSearching] = useState(false)
  const [showSearchResults, setShowSearchResults] = useState(false)

  useEffect(() => {
    // Fetch genres
    fetch(`https://api.themoviedb.org/3/genre/movie/list?api_key=${API_KEY}`)
      .then((res) => res.json())
      .then((data) => {
        const genreMap: { [key: number]: string } = {}
        data.genres.forEach((genre: Genre) => {
          genreMap[genre.id] = genre.name
        })
        setGenres(genreMap)
      })

    // Fetch popular movies for banner
    fetch(`https://api.themoviedb.org/3/movie/popular?api_key=${API_KEY}&page=1`)
      .then((res) => res.json())
      .then((data) => setPopularMovies(data.results.slice(0, 5)))

    // Fetch upcoming movies
    fetch(`https://api.themoviedb.org/3/movie/upcoming?api_key=${API_KEY}&page=1`)
      .then((res) => res.json())
      .then((data) => setUpcomingMovies(data.results))

    // Fetch trending movies
    fetch(`https://api.themoviedb.org/3/trending/movie/week?api_key=${API_KEY}&page=1`)
      .then((res) => res.json())
      .then((data) => setTrendingMovies(data.results))

    // Fetch top rated movies
    fetch(`https://api.themoviedb.org/3/movie/top_rated?api_key=${API_KEY}&page=1`)
      .then((res) => res.json())
      .then((data) => setTopRatedMovies(data.results))
  }, [])

  useEffect(() => {
    // Add scroll event listener for header background
    const handleScroll = () => {
      const header = document.querySelector(".header")
      if (window.scrollY > 50) {
        header?.classList.add("scrolled")
      } else {
        header?.classList.remove("scrolled")
      }
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const handleSearch = (query: string) => {
    if (!query.trim()) {
      setShowSearchResults(false)
      return
    }

    fetch(`https://api.themoviedb.org/3/search/movie?api_key=${API_KEY}&query=${query}&page=1&include_adult=false`)
      .then((res) => res.json())
      .then((data) => {
        setSearchResults(data.results)
        setShowSearchResults(true)
      })
  }

  const getGenreString = (genreIds: number[]) => {
    return genreIds
      .map((id) => genres[id])
      .filter(Boolean)
      .join(", ")
  }

  const handleMovieClick = (movieId: number) => {
    localStorage.setItem("movieId", movieId.toString())
  }

  return (
    <div className="min-h-screen bg-[#141414] text-white">
      {/* Splash Screen */}
      <SplashScreen />

      {/* Header */}
      <Header onSearch={handleSearch} searchResults={searchResults} showSearchResults={showSearchResults} />

      <main className="pt-16">
        {/* Search Results */}
        {showSearchResults && (
          <div className="search-modal fixed inset-0 bg-[#141414] pt-20 px-5 pb-5 overflow-y-auto z-40">
            <p className="text-[#e50914] font-bold text-sm mb-2">Results for</p>
            <h1 className="text-3xl font-bold mb-6">{searchQuery}</h1>

            <div className="movie-list">
              <div className="grid-list grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
                {searchResults.map((movie) => (
                  <MovieCard key={movie.id} movie={movie} onClick={handleMovieClick} />
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Banner */}
        {popularMovies.length > 0 && (
          <BannerSlider movies={popularMovies} genres={genres} onMovieClick={handleMovieClick} />
        )}

        {/* Movie Lists */}
        <MovieList title="Upcoming Movies" movies={upcomingMovies} onMovieClick={handleMovieClick} />
        <MovieList title="Weekly Trending Movies" movies={trendingMovies} onMovieClick={handleMovieClick} />
        <MovieList title="Top Rated Movies" movies={topRatedMovies} onMovieClick={handleMovieClick} />

        {/* TV Series Section */}
        <SeriesSection />
      </main>

      {/* Bottom Navigation */}
      <BottomNav />
    </div>
  )
}

interface MovieListProps {
  title: string
  movies: Movie[]
  onMovieClick: (id: number) => void
}

function MovieList({ title, movies, onMovieClick }: MovieListProps) {
  if (!movies.length) return null

  return (
    <section className="movie-list px-5 mb-6">
      <div className="title-wrapper flex items-center justify-between mb-4">
        <h3 className="title-large text-2xl font-bold text-white">{title}</h3>
        <Link href="#" className="see-all text-sm">
          See All
        </Link>
      </div>

      <div className="slider-list -mx-5 overflow-x-auto pb-4 mb-6 scrollbar-hide">
        <div className="slider-inner flex gap-2 px-5 relative">
          {movies.map((movie) => (
            <MovieCard key={movie.id} movie={movie} onClick={onMovieClick} />
          ))}
        </div>
      </div>
    </section>
  )
}

